﻿using System;


namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {

            double f = 40;
            double c = (f - 32) * 5 / 9;
            Console.WriteLine(c);

        }
    }
}
