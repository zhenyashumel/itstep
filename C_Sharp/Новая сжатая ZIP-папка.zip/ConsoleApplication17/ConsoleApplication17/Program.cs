﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleApplication17
{
    class Program
    {
        static void Main(string[] args)
        {   
            Console.Write("Enter a: ");
            Environment.Exit(0);
            string value = Console.ReadLine();
            int valuea = Convert.ToInt32(value);
            Console.WriteLine(valuea);
            
        }
    }
    
}
