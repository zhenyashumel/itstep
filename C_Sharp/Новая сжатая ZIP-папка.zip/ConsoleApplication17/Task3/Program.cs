﻿using System;

namespace Task3
{
    class Program
    {
        static void Main(string[] args)
        {
            string str ="";
            string[] first = new[] {"Сто", "Двести", "Триста", "Четыреста", "Пятьсот", "Шестьсот", "Семьсот", "Восемьсот", "Девятьсот"};
            string[] second = new[] { "Десять", "Двадцать", "Тридцать", "Сорок", "Пятьдесят", "Шестьдесят", "Семдесят", "Восемьдесят", "Девяносто"};
            string[] third = new[] { "Один", "Два", "Три", "Четыре", "Пять", "Шесть", "Семь", "Восемь", "Девять" };
            Console.WriteLine("Enter a number from 100 to 999:");
            int numb = Convert.ToInt32(Console.ReadLine());

            if(numb < 100 || numb > 999)
            {
                Console.WriteLine("Invalid number!!!");
                return;
            }

            int h = numb / 100;
            int d = numb % 100 / 10;
            str += first[h - 1] + ' ';
            if(d != 0)
                str += second[d - 1] + ' ';
            int ed = numb % 100 % 10;
            if (ed != 0)
                str += third[ed - 1];
            Console.WriteLine(str);            
           

        }
    }
}
