﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day14
{
    public class Card
    {
        private Values value;
        public Values Value
        {
            get
            {
                return value;
            }

            set
            {
                this.value = value;
            }
        }

        private Suits suit;
        public Suits Suit
        {
            get
            {
                return suit;
            }

            set
            {
                suit = value;
            }
        }
        public Card(Values value, Suits suit)
        {
            this.suit = suit;
            this.value = value;
        }
        public override string ToString()
        {
            return Value.ToString() + " " + Suit.ToString();
        }
    }
}
