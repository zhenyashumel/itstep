﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day14
{
    public class DeckCreator
    {
        public List<Card> CreateDeck()
        {
            Array arrValues = Enum.GetValues(typeof(Values));
            Array arrSuits = Enum.GetValues(typeof(Suits));

            var lstCards = new List<Card>();
            for (int i = 0; i < arrValues.Length; i++)
            {
                for (int j = 0; j < arrSuits.Length; j++)
                {
                    var val = (Values)arrValues.GetValue(i);
                    var suit = (Suits)arrSuits.GetValue(j);
                    Card newCard = new Card(val, suit);
                    lstCards.Add(newCard);                    
                }
            }
            return lstCards;

        }
    }
}
