﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day14
{
    class Player
    {
        private Queue<Card> cards;
        
        private string name;
       

        public Player(string name, Queue<Card> cards)
        {
            if (String.IsNullOrEmpty(name))
                throw new ArgumentException("Invalid name");

            this.cards = new Queue<Card>(cards);
            this.name = name;
        }

        public Card Cards
        {
            get
            {
                return cards.Dequeue();
            }           
        }
        
        public void Add(List<Card> lstCards)
        {
            foreach (var card in lstCards)
                cards.Enqueue(card);
        }

        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public void GetCards()
        {
            foreach(var card in Cards)
            {
                Console.WriteLine(card);
            }
        }
    }
}
