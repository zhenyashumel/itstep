﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Linq;

namespace DemoXml
{
    public static class WheatherHelper
    {
        private static string url;
        static WheatherHelper()
        {
            FileStream file = new FileStream("city.ini", FileMode.Open);
            url = @"http://informer.gismeteo.by/rss/26850.xml";

        }
        public static List<WheatherInfo> GetWheather()
        {
            List<WheatherInfo> wheatherlst = new List<WheatherInfo>();

            XDocument doc = XDocument.Load(url);

            foreach(var item in doc.Root.Element("channel").Elements())
            {
                if (item.Name.LocalName.Equals("item"))
                {
                    WheatherInfo element = new WheatherInfo()
                    {
                        title = item.Element("title").Value,
                        description = item.Element("description").Value,
                    };
                    wheatherlst.Add(element);
                }
            }

            return wheatherlst;
        }
    }
}
