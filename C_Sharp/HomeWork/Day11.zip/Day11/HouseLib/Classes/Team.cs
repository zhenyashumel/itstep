﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HouseLib
{
    class Team 
    {
        private Teamleader teamLeader;
        private Worker[] team;
        private int curWorker;

        public Team()
        {
            team = new Worker[11];
            
            teamLeader = new Teamleader();
            for (int i = 0; i < 11; i++)
                team[i] = new Worker();
            curWorker = 0;
        }
        
        public void build(House house)
        {
            team[curWorker].Work(house);
            curWorker++;
        }
        
    }
}
