﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HouseLib
{
    public class Teamleader : iWorker
    {
        public void Work(House obj)
        {
            for(int i = 0; i < obj.Parts.Length; i++)
            {
                if (obj.Parts[i].Status)
                    obj.Report += obj.Parts[i].Name + " is built.\n";
                else return;                      

            }
        }
    }
}
