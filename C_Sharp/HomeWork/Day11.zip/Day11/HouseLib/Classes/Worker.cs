﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HouseLib
{
    public class Worker: iWorker
    {
        public void Work(House house)
        {
            for(int i = 0; i < house.Parts.Length; i++)
            {
                if(!house.Parts[i].Status)
                {
                    house.Parts[i].add();
                    return;
                }
            }           
        }

       
    }
}
