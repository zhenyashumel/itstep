﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HouseLib
{
    class Basement : IPart
    {
        private bool built;
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public Basement()
        {
            name = "Basement";
            built = false;
        }
        public void add()
        {
            built = true;
        }

        public bool Status
        {
            get { return built; }
        }
    }
}
