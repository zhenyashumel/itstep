﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HouseLib
{
    public class House
    {
        private IPart[] parts;
        private Team team;
        private string report;

        public House()
        {
            parts = new IPart[]
            {
             new Door(), new Basement(), new Roof(),
             new Walls(), new Walls(), new Walls(), new Walls(),
             new Window(), new Window(), new Window(), new Window()
            };
            report = "";
            team = new Team();

        }

        public  bool HouseIsBuilt()
        {
            for (int i = 0; i < parts.Length; i++)
                if (!parts[i].Status)
                    return false;
            return true;
        }
        public void build()
        {
            while(!HouseIsBuilt())
            {
                team.build(this);
            }
        }
        public string Report
        {
            get
            {               
               return report;                
            }
            set { report = value; }
        }
        public IPart[] Parts
        {
            get { return parts; }
        }
    }
}
