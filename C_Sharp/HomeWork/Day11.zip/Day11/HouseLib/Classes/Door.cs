﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HouseLib
{
    class Door : IPart
    {
        private bool built;
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public Door()
        {
            built = false;
            name = "Door";
        }
        public void add()
        {
            built = true;
        }

        public bool Status
        {
            get { return built; }
        }
    }
}
