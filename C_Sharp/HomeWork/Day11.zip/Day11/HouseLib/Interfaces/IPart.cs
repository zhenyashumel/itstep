﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace HouseLib
{
    public interface IPart
    {
        void add();
        bool Status{ get;}
        string Name { get;}
    }
}
