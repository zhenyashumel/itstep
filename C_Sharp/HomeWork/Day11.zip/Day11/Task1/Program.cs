﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HouseLib;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
           
                House house = new House();
                house.build();
                Teamleader tl = new Teamleader();
                tl.Work(house);
                Console.WriteLine(house.Report);
           
        }
    }
}
