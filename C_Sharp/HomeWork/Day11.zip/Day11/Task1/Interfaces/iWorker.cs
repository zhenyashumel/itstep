﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task1.Classes;

namespace Task1.Interfaces
{
    interface iWorker
    {
        void work(House house);
    }
}
