﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WoT
{
    class Platoon
    {
        private Tank[] team;
        public Platoon(int count, string name)
        {
            if (count < 0 || String.IsNullOrEmpty(name)) throw new ArgumentException("Кол-во участников взвода не может быть меньше 1!!!");

            team = new Tank[count];
            for(int i = 0; i < count; i++)
            {
                team[i] = new Tank(name);
            }
        }
        public Tank[] Team
        {
            get { return team; }
        }
    }
}
