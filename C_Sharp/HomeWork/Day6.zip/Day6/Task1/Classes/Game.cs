﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WoT
{
    class Game
    {
        private Platoon team1;
        private Platoon team2;
        private int count;
        public Game(int count)
        {
            team1 = new Platoon(count, "T-34");
            team2 = new Platoon(count, "Pantera");
            this.count = count;
        }

        public void Start()
        {
            Console.ForegroundColor = ConsoleColor.Red; 
            Console.WriteLine("Состав\t Боекомплект\tУровень брони\tМаневренность");
            Console.WriteLine(new string('-', 50));

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Green;
            for (int i = 0; i < count; i++)
            {
                Console.Write("Бой " + (i + 1));
                Console.WriteLine(new string('-', 50));
                Console.WriteLine();

                Console.Write(team1.Team[i].Name + '\t');
                Console.WriteLine(team1.Team[i].GetStat());
                Console.Write(team2.Team[i].Name + '\t');
                Console.WriteLine(team2.Team[i].GetStat());
            }
           
                Console.WriteLine(new string('-', 60));

            Console.WriteLine();
            int t34 = 0;
            int pant = 0;

            for (int i = 0; i < count; i++)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Бой " + (i + 1) + " " + team1.Team[i].Name + "^" + team2.Team[i].Name + " ");

                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Победа " + (team1.Team[i]^team2.Team[i]).Name);
                
                if ((team1.Team[i] ^ team2.Team[i]).Name.Equals("T-34"))
                    t34++;
                else
                    pant++;
            }
            Console.WriteLine(new string('-', 60));
            Console.WriteLine();
            Console.WriteLine("Победа " + (t34 > pant ? "T-34" : "Pantera"));


        }

        
        

    }
}
