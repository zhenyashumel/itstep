﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WoT
{
     class Tank
    {
        private string name;
        private int ammunition;
        private int armor;
        private int mobility;
        private static Random rd = new Random();

        public Tank(string name)
        {
            Name = name;
            Ammunition = rd.Next(101);
            Armor = rd.Next(101);
            Mobility = rd.Next(101);
        }
        
        public  string GetStat()
        {
            string str = "";
            str += Ammunition + "\t\t";
            str += Armor + "\t\t";
            str += Mobility;
            return str;
        }
        public static Tank operator ^(Tank obj1, Tank obj2)
        {
            int first = 0;
            int second = 0;

            if (obj1.Ammunition > obj2.Ammunition)
                first++;
            else
                second++;

            if (obj1.Armor > obj2.Armor)
                first++;
            else
                second++;

            if (obj1.Mobility > obj2.Mobility)
                first++;
            else
                second++;

            return first > second ? obj1 : obj2;
        }
        #region Accessors
     

        public string Name
        {
            get { return name; }
            private set { name = value;}

        }
        public int Ammunition
        {
            get { return ammunition; }
            private set
            {
                if (value > 0 && value < 101)
                    ammunition = value;
            }

        }
        public int Armor
        {
            get { return armor; }
            private set
            {
                if (value > 0 && value < 101)
                   armor = value;
            }

        }

        public int Mobility
        {
            get { return mobility; }
            private set
            {
                if (value > 0 && value < 101)
                    mobility = value;
            }

        }
        #endregion
    }
}
