﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WoT
{
    class Program
    {
        static void Main(string[] args)
        {
            Game obj = new Game(5);
            obj.Start();
            Console.Read();
        }
    }
}
