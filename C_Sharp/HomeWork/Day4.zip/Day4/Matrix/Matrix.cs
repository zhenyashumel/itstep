﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Matrix
    {
        #region Fields
        private int sizeA;
        private int sizeB;
        private int[,] arr;

        #endregion

        #region Init

        /// <summary>
        ///matrix initialization at object level(constructor)
        /// </summary>
       
        public Matrix(int a, int b)
        {
            if(a > 1 && b > 1)
            {
                SizeA = a;
                SizeB = b;
            }
            else
            {
                SizeA = 5;
                SizeB = 5;
            }
            arr = new int[SizeA, SizeB];
            Random rm = new Random();
            for (int i = 0; i < SizeA; i++)
            {
                for (int j = 0; j < SizeB; j++)
                    arr[i, j] = rm.Next() % 1000;
            }

        }


     
        /// <summary>
        /// matrix initialization at the class level
        /// </summary>
        /// <param name="obj">Matrix object</param>
        public static void Init(Matrix obj)
        {
            Random rm = new Random();
            for (int i = 0; i < obj.SizeA; i++)
            {
                for (int j = 0; j < obj.SizeB; j++)
                    obj.arr[i, j] = rm.Next() % 10; //10 для того, чтобы лучше видеть результаты функции
            }
        }




        /// <summary>
        /// matrix initialization at the class level
        /// </summary>
        /// <param name="obj">Matrix object</param>
        public static void InitDef(Matrix obj)
        {
            obj.InitDef();
        }


        /// <summary>
        /// matrix initialization at the object level
        /// </summary>
        /// <param name=""></param>
        public void InitDef()
        {
            for (int i = 0; i < sizeA; i++)
            {
                for (int j = 0; j < sizeB; j++)
                    arr[i, j] = 0;
            }
        }

        /// <summary>
        /// Manual initialization at the object level
        /// </summary>
        public void UserInit()
        {
            for (int i = 0; i < sizeA; i++)
            {
                for (int j = 0; j < sizeB; j++)
                {
                    Console.Write("Введите число для числа матрицы(" + i + ", " + j + "):");
                    arr[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
        }

        /// <summary>
        /// Manual initialization at the class level
        /// </summary>
        public static void UserInit(Matrix obj)
        {
            obj.UserInit();
        }

     
        #endregion

        #region Accessors

        public int SizeA
        {
            get { return sizeA; }
            private set { sizeA = value; }
        }

        public int SizeB
        {
            get { return sizeB; }
            private set { sizeB = value; }
        }

        /// <summary>
        /// matrix printing
        /// </summary>
        public void Print()
        {
            for (int i = 0; i < sizeA; i++)
            {
                for (int j = 0; j < sizeB; j++)
                    Console.Write(arr[i, j] + " ");
                Console.WriteLine();
            }
            Console.WriteLine();
        }

        public int Min
        {
            get
            {
                int min = arr[0, 0];
                for (int i = 0; i < sizeA; i++)
                {
                    for (int j = 0; j < sizeB; j++)
                        if (arr[i, j] < min)
                            min = arr[i, j];
                }
                return min;
            }
        }

        public int Max
        {
            get
            {
                int max = arr[0, 0];
                for (int i = 0; i < sizeA; i++)
                {
                    for (int j = 0; j < sizeB; j++)
                        if (arr[i, j] > max)
                           max = arr[i, j];
                }
                return max;
            }
        }

        #endregion

        #region Diagonals

        /// <summary>
        /// exchange of diagonals at the object level
        /// </summary>
        public bool ExchangeDiag()
        {
            if (!SizeA.Equals(SizeB))
            {
                Console.WriteLine("The matrix must be square");
                return false;
            }
                    
            for (int i = 0; i < sizeA; i++)
            {
                for (int j = 0; j < sizeB; j++)
                {
                    if (i == j)
                    {
                        int buf = arr[i, sizeA - i - 1];
                        arr[i, sizeA - i - 1] = arr[i, j];
                        arr[i, j] = buf;
                    }
                }

            }
            return false;
        }

        /// <summary>
        /// exchange of diagonals at the class level
        /// </summary>
        /// <param name="obj">matrix object</param>
        public static void ExchangeDiag( Matrix obj)
        {
            obj.ExchangeDiag();
        }

      
        #endregion

        #region Multiplication 

        /// <summary>
        /// matrix multiplication at the object level
        /// </summary>
        /// <param name="obj">object of class matrix</param>
        public bool Mult(Matrix obj)
        {
            if (!SizeA.Equals(obj.SizeA) ||!SizeB.Equals(obj.SizeB))
            {
                Console.WriteLine("Matrices must be equal");
                return false;
            }

            for (int i = 0; i < SizeA; i++)
            {
                for (int j = 0; j < sizeB; j++)
                    arr[i, j] *= obj.arr[i, j];
            }
            return true;
        }

        /// <summary>
        /// matrix multiplication at the class level
        /// </summary>
        /// <param name="obj1">object of class matrix</param>
        /// <param name="obj2">object of class matrix</param>
        /// <returns></returns>
        public static void Mult(Matrix obj1, Matrix obj2)
        {
            if (!obj1.SizeA.Equals(obj2.SizeA) || !obj1.SizeB.Equals(obj2.SizeB))
            {
                Console.WriteLine("Matrices must be equal");
                return;
            }
            for (int i = 0; i < obj1.SizeA; i++)
            {
                for (int j = 0; j < obj1.sizeB; j++)
                    obj1.arr[i, j] = obj2.arr[i, j];
            }
        }
        #endregion

        #region Transposition

        /// <summary>
        /// Transpose the matrix at the object level
        /// </summary>
        public void Transposition()
        {
            int[,] tmp = new int[SizeB, SizeA];

            for (int i = 0; i < sizeB; i++)
                for (int j = 0; j < sizeA; j++)
                    tmp[i, j] = arr[j, i];

            arr = tmp;
            int temp = SizeA;
            SizeA = SizeB;
            SizeB = temp;
        }

        /// <summary>
        /// ranspose the matrix at the class level
        /// </summary>
        /// <param name="obj">object of class matrix</param>
        public static void Transposition(Matrix obj)
        {
            obj.Transposition();
        }

        #endregion

        #region Sort

        /// <summary>
        /// sort the matrix at the object level
        /// </summary>
        public void Sort()
        {
            int[] tmp = new int[SizeA * SizeB + 1];

            for (int i = 0; i < SizeA; i++)
                for (int j = 0; j < SizeB; j++)
                    tmp[i * SizeB + j] = arr[i, j];

            Array.Sort(tmp);
            for (int i = 0; i < SizeA; i++)
                for (int j = 0; j < SizeB; j++)
                    arr[i, j] = tmp[i * SizeB + j];
        }

        /// <summary>
        /// matrix sorting at the class level
        /// </summary>
        /// <param name="obj">Matrix object</param>
        public static void Sort(Matrix obj)
        {
            obj.Sort();
        }
      


        #endregion

    }

}
