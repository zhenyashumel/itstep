﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("The original matrix");
            Matrix obj = new Matrix(10, 20);
            obj.Print();

            Console.WriteLine("Matrix initialized by default");
            obj.InitDef();
            obj.Print();

            Console.WriteLine("The matrix is newly initialized");
            Matrix.Init(obj);
            obj.Print();

            Console.WriteLine("Diagonal change");
            if(obj.ExchangeDiag())
                obj.Print();
            Console.WriteLine();

            
            Matrix obj1 = new Matrix(10, 10);
            Console.WriteLine("Matrix number 1");
            obj.Print();
            Console.WriteLine("Matrix number 2");
            obj1.Print();
            Console.WriteLine("Multiplication of Matrices");
            if (obj.Mult(obj1) == true)           
                obj.Print();
            Console.WriteLine();
            

           
            Console.WriteLine("Transpose the matrix");
            Console.WriteLine("Before");
            Matrix.Init(obj);
            obj.Print();
            Console.WriteLine("After");
            obj.Transposition();
            obj.Print();

            Console.WriteLine("Sorting an Array");
            obj.Sort();
            obj.Print();






        }
    }
}
