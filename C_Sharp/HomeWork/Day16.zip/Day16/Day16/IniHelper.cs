﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Day16
{
    class IniHelper
    {
        private Dictionary<string, Dictionary<string, string>> sections;

        public IniHelper()
        {
            sections = new Dictionary<string, Dictionary<string, string>>();
            StreamReader streamreader = new StreamReader("InitFile.ini",Encoding.Default);

            string tmp;
            while (!streamreader.EndOfStream)
            {
                string patternSection = @"^\[[azA-Z]\w+\]$";
                string patternKeyValue = @"^[a-zA-Z]\w+?=[a-zA-Z]\w+?";
                tmp = streamreader.ReadLine();
                if (Regex.IsMatch(tmp, patternSection))
                {
                    tmp.Substring(1, tmp.Length - 1);
                    sections.Add(tmp, null);
                }
                                
                if (Regex.IsMatch(tmp, patternKeyValue))
                {
                  
                    string key = Regex.Match(tmp, @"\w+(?=\=)").Value;
                    string value = Regex.Match(tmp, @"(?<=\=)\w+").Value;                    

                }
            }
        }

        public T GetKeyValue<T>(string sSection, string sKey, T sDefault)
        {

        }
    }
}
