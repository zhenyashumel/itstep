﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoClassLib.Parts
{
    public class Radio
    {
        private bool isOn;

        public bool MyProperty
        {
            get { return isOn; }
            set { isOn = value; }
        }

    }
}
