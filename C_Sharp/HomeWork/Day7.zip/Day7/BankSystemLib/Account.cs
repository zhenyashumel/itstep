﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankSystemLib
{
    class Account
    {
        static int numb = 1;
        private int number;
        private int proc;
        private decimal balance;
        public Account()
        {
            balance = 0;
            number = numb;
            numb++;
            Random rd = new Random();
            proc = rd.Next(10);
        }

    }
}
