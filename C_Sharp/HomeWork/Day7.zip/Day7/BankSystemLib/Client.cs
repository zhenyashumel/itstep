﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BankSystemLib
{
    public  class Client
    {
        private Account[] accounts;
        private int numbOfAcc;
        private string login;
        private string password;
        private string name;
        private string surname;
        private string passportID;

        public Client(string log, string pas, string nam, string surnam, string passportId)
        {

            if (string.IsNullOrEmpty(log))
                throw new ArgumentException("The passed login is empty!!!");

            if (string.IsNullOrEmpty(pas))
                throw new ArgumentException("The passed password is empty!!!");

            if (string.IsNullOrEmpty(nam))
                throw new ArgumentException("The passed name is empty!!!");

            if (string.IsNullOrEmpty(surnam))
                throw new ArgumentException("The passed surname is empty!!!");

            if (string.IsNullOrEmpty(passportId))
                throw new ArgumentException("The passed passport ID is empty!!!");

            accounts = new Account[100];
            Login = log;
            password = pas;
            numbOfAcc = 0;
            passportID = passportId;

            name = nam;
            surname = surnam;
            accounts[numbOfAcc] = new Account();
        }
        public string Login
        {
            get { return login; }
            set { login = value; }
        }
    }
}
