﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankSystemLib;

namespace BankProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            Bank b = new Bank();
            Client a = new Client("123","123", "Hello", "123", "55467");
            if( b.CreateUser(a))
                Console.WriteLine("Yes");
            else
                Console.WriteLine("No");

            Client c = new Client("123", "123", "Hello", "123", "55467");

            if (b.CreateUser(c))
                Console.WriteLine("Yes");
            else
                Console.WriteLine("No");


        }
    }
}
