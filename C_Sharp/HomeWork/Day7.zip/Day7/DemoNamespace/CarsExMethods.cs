﻿using DemoClassLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoNamespace
{
    static class CarsExMethods
    {
        public static void AddFuel(this Car car)
        {
            Console.WriteLine(car.GetInfo());
        }
    }
}
