﻿using BankSystemLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProgram
{
    static class Terminal
    {
        public static bool Registration(this Bank bank)
        {
            try
            {
                Console.Write("Enter login:");
                string log = Console.ReadLine();


                bool user = bank.FoundClient(log);

                if (!user)
                {
                    Console.Write("Enter password: ");
                    string password = Console.ReadLine();
                    if (!BankSecurity.Check(password))
                    {
                        Console.WriteLine("Too light password!!!");
                        return false;
                    }

                    Console.Write("Enter your name: ");
                    string nam = Console.ReadLine();

                    Console.Write("Enter your surname: ");
                    string surnam = Console.ReadLine();

                    Console.Write("Enter your passportId: ");
                    string passportId = Console.ReadLine();

                    Client client = new Client(log, password, nam, surnam, passportId);


                    if (bank.CreateUser(client))
                        return true;
                }
                else
                {
                    Console.WriteLine("User with such login already exists");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return false;
        }

        public static Client Authorization(this Bank obj)
        {
            Console.Write("Enter login:");
            string log = Console.ReadLine();

            Console.Write("Enter password: ");
            string password = Console.ReadLine();

            Client client = obj.GetUser(log, password);

            if (client != null)
                return client;

            Console.WriteLine("Invalid username or password!!!");
            return null;

        }

        public static void Menu(this Bank obj)
        {
            bool menu1 = true;
            bool menu2 = true;
            Client curClient = null;

            while (menu1)
            {

                Console.WriteLine("1.Create an account.");
                Console.WriteLine("2.Sign in to your account.");
                Console.Write("Your choice: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        if (obj.Registration())
                        {
                            Console.Clear();
                            Console.WriteLine("Account successfully created!!!");
                        }
                        break;
                    case "2":
                        int countLogin = 0;
                        while (countLogin <= 3)
                        {
                            curClient = obj.Authorization();
                            if (curClient != null)
                            {
                                menu1 = false;
                                break;
                            }
                            countLogin++;

                            if (countLogin.Equals(3))
                            {
                                Console.WriteLine("You used all the attempts !!! Exit!!!");
                                Console.Read();
                                Environment.Exit(0);
                            }
                        }
                        break;
                    default:
                        Console.WriteLine("Enter the correct menu item!!!");
                        break;
                }
            }

            while (menu2)
            {
                Console.WriteLine("1.Display the balance.\n2.Refill.\n3.Withdraw money from the account.\n4.Exit");
                Console.Write("Your choice: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        for(int i = 0; i < curClient.NumbOfAcc; i++)
                        {
                            Console.Write("Account number " + curClient.GetAcc()[i].Numb + " Balance: " 
                                + curClient.GetAcc()[i].Balance + "\n");

                        }
                        Console.WriteLine();
                        break;

                    case "2":
                        Console.Write("How much money do we put: ");
                        string input = Console.ReadLine();
                        if (!char.IsNumber(Convert.ToChar(input)))
                            Console.WriteLine("You entered an invalid amount!!!");
                        else
                        {
                            int put = Convert.ToInt32(input);
                            if(put < 0)
                                Console.WriteLine("You entered an invalid amount!!!");
                            else
                            {

                            }
                        }
                        break;

                     

                }
            }


        }

    }
}

