﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankProgram
{
    class BankSecurity
    {
        public static bool Check(string password)
        {
            if(string.IsNullOrEmpty(password))
                throw new ArgumentException("The entered login is empty!!!");

            bool numb = false;
            bool up = false;
            bool count = password.Length > 7 ? true: false;

            for(int i = 0; i < password.Length; i++)
            {
                if (char.IsUpper(password[i]))
                    up = true;

                if (char.IsDigit(password[i]))
                    numb = true;
                 
            }
            return (numb && up && count);

        }
    }
}
