﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Test.Complex.My;
using DemoNamespace.ITStep;
using static System.Math;
using DemoClassLib;
using DemoClassLib.Parts;

namespace DemoNamespace
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car();
            car.Move();
            car.AddFuel();
        }
    }

   

       

}
namespace Test.Complex.My
{
    class A
    {
    }

}
