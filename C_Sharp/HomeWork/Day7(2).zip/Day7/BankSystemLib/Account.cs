﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankSystemLib
{
    public class Account
    {
        static int numb = 0;
        private int number;
        private double proc;
        private decimal balance;
        public Account()
        {
            balance = 0;
            number = numb;
            numb++;
            Random rd = new Random();
            proc = rd.Next(10) / 100;
        }

        public decimal Balance
        {
            get { return balance; }
            private set { balance = value; }
        }
        public int Numb
        {
            get { return numb; }
            private set { numb = value; }
        }


    }
}
