﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BankSystemLib
{
    public class Bank
    {
        private Client[] clients;
        private int numbOfClients;
        public Bank()
        {
            numbOfClients = 0;
            clients = new Client[100];
        }

      public Client GetUser(string log, string password)
        {
            if (string.IsNullOrEmpty(log))
                throw new ArgumentException("The entered login is empty!!!");

            for(int i = 0; i < numbOfClients; i++)
            {
                if (log.Equals(clients[i].Login))
                {
                    if (clients[i].Password.Equals(password))
                        return clients[i];
                    else
                        return null;
                }
                   
            }
            return null;
        }

        public bool FoundClient(string log)
        {
            if (string.IsNullOrEmpty(log))
                throw new ArgumentException("The entered login is empty!!!");

            for (int i = 0; i < numbOfClients; i++)
            {
                if (log.Equals(clients[i].Login))
                    return true;
            }
            return false;
                    
        }
        public bool CreateUser(Client obj)
        {
          
            bool flag = false;
            for(int i = 0; i < numbOfClients; i++)
            {
                if (clients[i].Login.Equals(obj.Login))
                    flag = true;
            }

            if (!flag)
            {
                clients[numbOfClients] = obj;
                numbOfClients++;
            }

            return !flag;
         }

    }
}
