﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Client : IAccount
    {
        private decimal summ;
        public Client()
        {
            summ = 100;
        }
        public decimal Account
        {
            get
            {
                return summ;
            }

            set
            {
                summ = value;
            }
        }
        
        public void Done(object sender, EventArgs e)
        {
            TransactionInfo tInfo = e as TransactionInfo;
            if(tInfo.Done)
                Console.WriteLine("Money successfully transferred");
            else
                Console.WriteLine("Money is not transferred");
        }
    }
}
