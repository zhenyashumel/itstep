﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            Client client1 = new Client();

            Client client2 = new Client();


            Transaction<Client> transaction = new Transaction<Client>();
            transaction.Done += client1.Done;
            transaction.Transfer(client1, client2, 100);

            Console.WriteLine(client2.Account);
            Console.Read();

        }
    }
}
