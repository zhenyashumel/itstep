﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class TransactionInfo:EventArgs
    {
        private bool done;
        public bool Done
        {
            get { return done; }
            set { done = value; }
        }
    }
}
