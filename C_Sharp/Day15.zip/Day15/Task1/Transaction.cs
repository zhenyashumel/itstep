﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Transaction<T> where T: IAccount
    {
        public event EventHandler Done;
        public void Transfer(T whence, T where, decimal amount)
        {
            TransactionInfo tInfo = new TransactionInfo();
            if (whence.Account < amount)
                tInfo.Done = false;
            else
            {
                whence.Account -= amount;
                where.Account += amount;
                tInfo.Done = true;
            }
           
            Done(whence, tInfo);           
           
        }

    }
}
