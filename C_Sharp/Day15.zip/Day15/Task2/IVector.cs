﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    interface IVector<T>
    {
        void Push_Back(T value);
        void Clear();
        void Remove(int index);
        void Sort();
        int Search(T value);
        void Insert(int index);

    }
}
