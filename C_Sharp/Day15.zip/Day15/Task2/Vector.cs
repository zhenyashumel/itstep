﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Vector<T>:IVector<T>
    {

        private T[] arr;
        private int size;
        private int capacity;
        public Vector()
        {
            capacity = 2;
            size = 0;
            arr = new T[capacity];
        }
        public void Push_Back(T value)
        {
            throw new NotImplementedException();
        }

        public void Clear()
        {
            throw new NotImplementedException();
        }

        public void Remove(int index)
        {
            throw new NotImplementedException();
        }

        public void Sort()
        {
            throw new NotImplementedException();
        }

        public int Search(T value)
        {
            throw new NotImplementedException();
        }

        public void Insert(int index)
        {
            throw new NotImplementedException();
        }

       
    }
}
