﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimulationLib
{
    class Simulation
    {
        private Aircraft aircraft;
        private bool OnSimulation;

        public Simulation()
        {
            aircraft = new Aircraft();
            OnSimulation = false;
        }

        public void StartSimulation()
        {
            if (aircraft.CountOfDispatchers < 2)
                //  throw new
                while (OnSimulation)
                {
                    ConsoleKeyInfo key = Console.ReadKey();
                    if ((key.Modifiers & ConsoleModifiers.Shift) != 0)
                    {
                        if(key.Key.Equals(ConsoleKey.LeftArrow))
                        {
                            aircraft.Speed -= 150;

                        }
                    }

                }
        }
    }
}

