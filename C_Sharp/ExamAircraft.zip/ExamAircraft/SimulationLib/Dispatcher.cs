﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimulationLib
{
    public class Dispatcher
    {
        private string name;
        private int adjustment; 

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="name">dispatcher name</param>
        public Dispatcher(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Name is empty!!!");
            Name = name;
            Random rnd = new Random();
            Adjustment = rnd.Next(-200, 200);
        }
        public string Name
        {
            get { return name; }
            private set { name = value; }
        }
        public int Adjustment
        {
            get { return adjustment; }
            set { adjustment = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <returns></returns>
        //public int HeightProcessing(object sender, EventArgs e)
        //{
            
        //}

    }
}
