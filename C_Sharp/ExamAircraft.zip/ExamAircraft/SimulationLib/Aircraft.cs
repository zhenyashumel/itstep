﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimulationLib
{
    public class Aircraft
    {
        private List<Dispatcher> dispatchers;
        private int height;
        private int speed;
        public event EventHandle ChangeSettings;


        public Aircraft()
        {
            dispatchers = new List<Dispatcher>();
        }

        public void AddDispatcher(Dispatcher dispatcher)
        {
            if (dispatcher.Equals(null))
                throw new ArgumentException("Dispatcher is null!!!");
            dispatchers.Add(dispatcher);
        }

        public int CountOfDispatchers
        {
            get { return dispatchers.Count; }
        }

        public int Speed
        {
            get
            {
                return speed;
            }

            set
            {
                speed = value;
            }
        }

        public int Height
        {
            get
            {
                return height;
            }

            set
            {
                height = value;
            }
        }
    }
}
