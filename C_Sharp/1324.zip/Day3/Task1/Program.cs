﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] A = new int[5];
            double[,] B = new double[3, 4];

            for(int i = 0; i < A.Length; i++)
            {
                Console.Write("Enter the number: ");
                A[i] = Convert.ToInt32(Console.ReadLine());
            }

            Random rd = new Random();
            for(int i = 0; i < B.GetLength(0); i++)
            {
                for (int j = 0; j < B.GetLength(1); j++)
                {
                    B[i, j] = rd.Next(0, 100);
                }
                
            }

            Console.WriteLine("A:");
            Console.WriteLine(String.Join(" ", A));
            Console.WriteLine(Environment.NewLine);


            Console.WriteLine("B:");
            for (int i = 0; i < B.GetLength(0); i++)
            {
                for (int j = 0; j < B.GetLength(1); j++)
                {
                    Console.Write(B[i, j] + " ");
                }
                Console.WriteLine(Environment.NewLine);

            }

            double max = 0;
            double summ = 0;
            double com = 1;
            double odd = 0;
            for(int i = 0; i < B.GetLength(0); i++)
            {
                for(int j = 0; j < B.GetLength(1); j++)
                {
                    summ += B[i, j];
                    com *= B[i, j];
                    if (B[i, j] > max)
                        max = B[i, j];
                    if (j % 2 == 0)
                        odd += B[i, j];
                }
            }

            Console.WriteLine("Max A: " + A.Max());
            Console.WriteLine("Max B: " + max);

            Console.WriteLine("Summ A: " + A.Sum());
            Console.WriteLine("Summ B: " + summ);

            int comA = 1;
            int even = 0;
            for (int i = 0; i < A.Length; i++)
            {
                comA *= A[i];
                if (A[i] % 2 == 0)
                    even += A[i];
            }

            Console.WriteLine("Composition A: " + comA);
            Console.WriteLine("Composition B: " + com);

            Console.WriteLine("Sum of even A: " + even);
            Console.WriteLine("Sum of odd B: " + odd);

            Array.Sort(A);
                       
            int min = -1;

            for (int x = 0; x < A.Length; x++)
            {
                for (int i = 0; i < B.GetLength(0); i++)
                {
                    for (int j = 0; j < B.GetLength(1); j++)
                    {
                        if (B[i, j] == A[x])
                        {
                            min = A[x];
                            break;
                        }
                    }
                }
            }

            if (min != -1)
                Console.WriteLine("No minimum common item found");
            else
                Console.WriteLine("The minimum common element: " + min);





        }
    }
}
