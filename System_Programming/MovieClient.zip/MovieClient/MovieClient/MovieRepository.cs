﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.TMDb;
using System.Threading;
using MovieClient.Entities;

namespace MovieClient
{
    public static class MovieRepository
    {

        public static async Task<List<MovieInfo>> GetTopMoviesAsync(CancellationToken cancellationToken)
        {
            List<MovieInfo> moviesResult = new List<MovieInfo>();
            using (var client = new ServiceClient("c6b31d1cdad6a56a23f0c913e2482a31"))
            {
                for (int i = 1, count = 1; i <= count; i++)
                {
                    var movies = await client.Movies.GetNowPlayingAsync(null, i, cancellationToken);
                    
                   //count = movies.PageCount; // keep track of the actual page count

                    foreach (Movie m in movies.Results)
                    {
                        var movie = await client.Movies.GetAsync(m.Id, null, true, cancellationToken);

                        var film = new MovieInfo()
                        {
                            Title = movie.Title,
                            Overview = movie.Overview,
                            Poster = movie.Poster,
                            ReleaseDate = movie.ReleaseDate
                        };
                    moviesResult.Add(film);


                    }
                }
            }
            return moviesResult;

        }

    }
}
