﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieClient.Entities
{
    public class MovieInfo
    {
        private string poster;
        private string title;
        private DateTime? releaseDate;
        private string overview;

        public string Poster { get => poster; set => poster = value; }
        public string Title { get => title; set => title = value; }
        public DateTime? ReleaseDate { get => releaseDate; set => releaseDate = value; }
        public string Overview { get => overview; set => overview = value; }

        public override string ToString() => title;
       
    }
}
