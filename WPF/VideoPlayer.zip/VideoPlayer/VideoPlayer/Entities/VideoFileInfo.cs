﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoPlayer.Entities
{
    public class VideoFileInfo
    {
        private string name;
        private string path;

        public VideoFileInfo(string Name, string Path)
        {
            if (String.IsNullOrWhiteSpace(Name))
                throw new ArgumentException("Name is null");
            if (String.IsNullOrWhiteSpace(Path))
                throw new ArgumentException("Path is null");

            name = Name;
            path = Path;
        }

        public string Name
        {
            get
            {
                return name;
            }

            
        }

        public string Path
        {
            get
            {
                return path;
            }

           
        }
        public override string ToString()
        {
            return Name;
        }
    }
}
