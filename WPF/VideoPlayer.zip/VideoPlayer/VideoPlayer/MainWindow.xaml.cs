﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using VideoPlayer.Entities;

namespace VideoPlayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ObservableCollection<VideoFileInfo> videos;
        private DispatcherTimer timer;
        public MainWindow()
        {
            InitializeComponent();
            videos = new ObservableCollection<VideoFileInfo>();
            lstVideos.ItemsSource = videos;
            timer = new DispatcherTimer();
            timer.Interval = new TimeSpan(1000);
            timer.Tick += Timer_Tick;
            Volume.Minimum = 0;
            Volume.Maximum = 100;

        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if (Media.NaturalDuration.HasTimeSpan)
            {

                string time= String.Format("{0:00}:{1:00}:{2:00}/{3}", Media.Position.Hours, Media.Position.Minutes, Media.Position.Seconds, Media.NaturalDuration.TimeSpan);
                if (!Time.Content.Equals(time))
                {
                    if(!Media.CanPause)
                        Progress.Value++;
                    Time.Content = time;
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.Filter = "(*.avi; *.mp4;)| *.avi; *.mp4; |(All files) |*.*";
            if (fileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                var files = fileDialog.FileNames;
                foreach (var element in files)
                    videos.Add(new VideoFileInfo(System.IO.Path.GetFileName(element), element));
                lstVideos.SelectedItem = lstVideos.Items[lstVideos.Items.Count - 1];
                Media.LoadedBehavior = MediaState.Manual;
                Media.Source = new Uri((lstVideos.SelectedItem as VideoFileInfo).Path);
                btnPlayAndPause.IsEnabled = true;
                btnStop.IsEnabled = true;

            }
        }

        private void Window_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (this.WindowState == WindowState.Normal)
            {

                this.WindowState = WindowState.Maximized;
            }
            else if (this.WindowState == WindowState.Maximized)
                this.WindowState = WindowState.Normal;
        }

        private void lstVideos_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Media.Source = new Uri((lstVideos.SelectedItem as VideoFileInfo).Path);
        }

        private void btnPlayAndPause_Click(object sender, RoutedEventArgs e)
        {
            if (lbbtn.Content.Equals("Play"))
            {
                Media.Play();
                lbbtn.Content = "Pause";
                Uri uri = new Uri("https://newcdn.iconfinder.com/data/icons/picol-vector/32/controls_pause-24.png");
                imgbtn.Source = BitmapFrame.Create(uri);
                timer.Start();

            }
            else
            {
                Media.Pause();
                lbbtn.Content = "Play";
                Uri uri = new Uri("https://newcdn.iconfinder.com/data/icons/eightyshades/512/23_Play-24.png");
                imgbtn.Source = BitmapFrame.Create(uri);
            }

        }

        private void Media_MediaOpened(object sender, RoutedEventArgs e)
        {
            Time.Content = String.Format("{0:00}:{1:00}:{2:00}/{3}", Media.Position.Hours, Media.Position.Minutes, Media.Position.Seconds, Media.NaturalDuration.TimeSpan);
            Progress.Minimum = 0;
            Progress.Maximum = (Media.NaturalDuration.TimeSpan.Hours * 3600) + (Media.NaturalDuration.TimeSpan.Minutes * 60) + Media.NaturalDuration.TimeSpan.Seconds;
            Progress.Value = 0;            
            Progress.Interval = 1;

        }

      

        private void Progress_DataContextChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Media.Pause();
            Media.Position = TimeSpan.FromSeconds(Progress.Value);
            Media.Play();
        }

        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            Media.Stop();
        }

        private void Volume_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Media.Volume = Volume.Value * 0.01;
        }

        private void Media_MediaEnded(object sender, RoutedEventArgs e)
        {
            if (lstVideos.SelectedIndex != lstVideos.AlternationCount - 1)
            {
                lstVideos.SelectedIndex++;
                Media.Source = new Uri((lstVideos.SelectedItem as VideoFileInfo).Path);
            }
        }
    }
}
