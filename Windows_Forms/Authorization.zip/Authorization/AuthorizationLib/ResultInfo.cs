﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthorizationLib
{
    public class ResultInfo
    {
        private int code; //0 - всё норм, 1 - неверный логин, 2 - неверный пароль

        private string message;

        public string Message
        {
            get { return message; }
            set { message = value; }
        }

        public int Code
        {
            get { return code; }
            set { code = value; }
        }

    }
}
