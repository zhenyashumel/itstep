﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthorizationLib
{
    [Serializable]
    public class UserInfo
    {
        private string name;
        private string surname;
        private string login;
        private string password;
        private string email;

        public UserInfo(string Name, string Surame, string Login, string Password, string Email)
        {
            if (String.IsNullOrWhiteSpace(Name))
                throw new ArgumentException("Name is empty!!!");
            if (String.IsNullOrWhiteSpace(Surame))
                throw new ArgumentException("Surname is empty!!!");
            if (String.IsNullOrWhiteSpace(Login))
                throw new ArgumentException("Login is empty!!!");
            if (String.IsNullOrWhiteSpace(Password))
                throw new ArgumentException("Password is empty!!!");
            if (String.IsNullOrWhiteSpace(Name))
                throw new ArgumentException("Email is empty!!!");

            name = Name;
            surname = Surame;
            login = Login;
            password = Password;
            email = Email;
        }

        public bool Checkpassword(string password)
        {
            return password.GetHashCode().Equals(this.password.GetHashCode()) ? true : false;
        }

    }
}
