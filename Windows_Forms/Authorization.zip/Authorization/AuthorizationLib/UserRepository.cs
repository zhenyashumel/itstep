﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthorizationLib
{
    public static class UserRepository
    {
        private static List<UserInfo> users;

        static UserRepository()
        {

            if (File.Exists("Users.txt"))
                Load("Users.txt");
            else
                users = new List<UserInfo>();

        }
        public static void Save(string path)
        {
            SerializerHelper.Serialize<UserInfo>(path, users);
        }

        public static void AddUser(UserInfo user)
        {
            if (user == null)
                throw new ArgumentException("User is null!!!");
            users.Add(user);

        } 
        public static void Load(string path)
        {
            users = SerializerHelper.Deserialize<UserInfo>(path) as List<UserInfo>;
        }

    }
}
