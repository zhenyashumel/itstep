﻿using Authorization.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Authorization
{
    public partial class AuthorizationForm : Form
    {
        public AuthorizationForm()
        {
            InitializeComponent();
        }

        private void llbforgotPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void AuthorizationForm_Load(object sender, EventArgs e)
        {
            
        }
        private void LoginFocus(object sender, EventArgs e)
        {
            if (tbLogin.Text.Equals("Имя пользователя"))
            {
                tbLogin.Text = "\0";
                tbLogin.ForeColor = Color.Empty;
            }
        }
        private void LostLoginFocus(object sender, EventArgs e)
        {
            if (tbLogin.Text.Equals(""))
            {
                tbLogin.ForeColor = Color.Gray;
                tbLogin.Text = ("Имя пользователя");
            }

        }

        private void PasswordFocus(object sender, EventArgs e)
        {
            if (tbPassword.Text.Equals("Пароль"))
            {
                tbPassword.Text = "\0";
                tbPassword.PasswordChar = '*';
                tbPassword.ForeColor = Color.Empty;
            }
        }
        private void LostPasswordFocus(object sender, EventArgs e)
        {
            if (tbPassword.Text.Equals(""))
            {
                tbPassword.ForeColor = Color.Gray;
                tbPassword.PasswordChar = '\0';
                tbPassword.Text = ("Пароль");
            }

        }

        private bool CheckData()
        {
            //todo
            bool check = false;
            tbLogin.BackColor = Color.Empty;
            tbPassword.BackColor = Color.Empty;
            if (tbLogin.Text == "")
            {
                check = true;
                tbLogin.BackColor = Color.Red;
            }
            if (tbPassword.Text == "")
            {
                check = true;
                tbPassword.BackColor = Color.Red;
            }
            return check;
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if(!CheckData())
            {

            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            RegistrationForm regForm = new RegistrationForm();         
            regForm.ShowDialog();
        }
    }
}
