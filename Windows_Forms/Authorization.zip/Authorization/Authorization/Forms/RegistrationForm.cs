﻿using AuthorizationLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Authorization.Forms
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void RegistrationForm_Load(object sender, EventArgs e)
        {

        }

        private bool CheckData()
        {
            bool check = false;
            lbInfo.Text = "";
            lbLog.Text = "";
            lbPas.Text = "";
            lbRepeat.Text = "";
            lbSur.Text = "";
            lbName.Text = "";
            lbMail.Text = "";
            tbMail.BackColor = Color.Empty;
            tbPassword.BackColor = Color.Empty;
            tbRepeatPassword.BackColor = Color.Empty;

            if (tbLogin.Text == "")
            {
                check = true;
                lbLog.Text = "*";
            }

            if (tbPassword.Text == "")
            {
                check = true;
                lbPas.Text = "*";
            }

            if (tbRepeatPassword.Text == "")
            {
                check = true;
                lbRepeat.Text = "*";
            }

            if (tbSurname.Text == "")
            {
                check = true;
                lbSur.Text = "*";
            }

            if (tbName.Text == "")
            {
                check = true;
                lbName.Text = "*";
            }

            if (tbMail.Text == "")
            {
                check = true;
                lbMail.Text = "*";
            }
            if (!Regex.IsMatch(tbMail.Text, @"\w+@\w+\.\w+"))
            {
                tbMail.BackColor = Color.Red;
                check = true;
            }

            if (!tbPassword.Text.Equals(tbRepeatPassword.Text))
            {
                tbPassword.BackColor = Color.Red;
                tbRepeatPassword.BackColor = Color.Red;
                check = true;
            }

            if (check)
                lbInfo.Text = "* - Поля для обязательного заполнения";
            return check;

        }
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (!CheckData())
            {
                UserInfo newUser = new UserInfo(tbName.Text,
                    tbSurname.Text, tbLogin.Text, tbPassword.Text, tbMail.Text);

                UserRepository.AddUser(newUser);
                this.Close();
            }

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
