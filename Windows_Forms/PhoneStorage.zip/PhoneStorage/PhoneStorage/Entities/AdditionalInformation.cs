﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneStorage.Entities
{
    public static class AdditionalInformation
    {
        private static List<string> manufacturers;
        private static List<string> countries;

        static AdditionalInformation()
        {
            manufacturers = new List<string>()
            {
                "Apple", "Huawei", "Samsung", "Nokia"
            };

            countries = new List<string>()
            {
                "Belarus", "Russia", "USA", "China"
            };
        }

        public static IReadOnlyList<string> Manufacturers
        {
            get { return manufacturers; }
        }
        public static IReadOnlyList<string> Countries
        {
            get { return countries; }
        }
        public static void AddCountry(string country)
        {
            if (String.IsNullOrWhiteSpace(country))
                throw new ArgumentException("Country is empty");

            if (!countries.Any(p => p.Equals(country)))
                countries.Add(country);
        }

        public static void AddManufacturer(string manufacturer)
        {
            if (String.IsNullOrWhiteSpace(manufacturer))
                throw new ArgumentException("manufacturer is empty");

            if (!manufacturers.Any(p => p.Equals(manufacturer)))
                manufacturers.Add(manufacturer);
        }
    }
}
