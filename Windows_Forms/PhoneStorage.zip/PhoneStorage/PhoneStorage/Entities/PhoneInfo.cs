﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneStorage.Entities
{
    public class PhoneInfo
    {
        private string name;

        private decimal price;

        private string country;

        private string manufacturer;

        public string Manufacturer
        {
            get { return manufacturer; }
            set { manufacturer = value; }
        }


        public string Country
        {
            get { return country; }
            set { country = value; }
        }


        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

    }
}
