﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SmartWord
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void cToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {

        }

        private void miOpen_Click(object sender, EventArgs e)
        {
            opfFile.Filter = "Text documents| *.txt|All files |*.*";
            if (opfFile.ShowDialog() == DialogResult.OK)
            {
                this.Text = opfFile.FileName;
                tbMain.Text = File.ReadAllText(opfFile.FileName, Encoding.Default);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {

        }

        private void miSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.FileName = "File.txt";
            sfd.Filter = "Text documents| *.txt|All files |*.*";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(sfd.FileName, tbMain.Text, Encoding.Default);
            }
        }



        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog dialog = new FontDialog();

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                tbMain.Font = dialog.Font;
            }
        }

        private void colorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog dialog = new ColorDialog();

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                tbMain.ForeColor = dialog.Color;
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
           
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                var files = Directory.GetFiles(dialog.SelectedPath, "*.txt");
                for (int i = 0; i < files.Length; i++)
                {
                    tbMain.Text += File.ReadAllText(files[i],Encoding.Default)+ Environment.NewLine;
                }
            }

        }
    }
}
