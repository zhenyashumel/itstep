﻿namespace DemoBars
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.trb1 = new System.Windows.Forms.TrackBar();
            this.trb2 = new System.Windows.Forms.TrackBar();
            this.trb3 = new System.Windows.Forms.TrackBar();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.picSystem = new System.Windows.Forms.PictureBox();
            this.picUser = new System.Windows.Forms.PictureBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.cbTime = new System.Windows.Forms.ComboBox();
            this.tbR = new System.Windows.Forms.TextBox();
            this.tbFinishR = new System.Windows.Forms.TextBox();
            this.tbFinishG = new System.Windows.Forms.TextBox();
            this.tbG = new System.Windows.Forms.TextBox();
            this.tbFinishB = new System.Windows.Forms.TextBox();
            this.tbB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.GameTimer = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbDelR = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbProcR = new System.Windows.Forms.TextBox();
            this.tbProcG = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbDelG = new System.Windows.Forms.TextBox();
            this.tbProcB = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbDelB = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.trb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSystem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picUser)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // trb1
            // 
            this.trb1.Enabled = false;
            this.trb1.Location = new System.Drawing.Point(14, 209);
            this.trb1.Maximum = 255;
            this.trb1.Name = "trb1";
            this.trb1.Size = new System.Drawing.Size(544, 45);
            this.trb1.TabIndex = 0;
            this.trb1.Scroll += new System.EventHandler(this.trb1_Scroll);
            this.trb1.ValueChanged += new System.EventHandler(this.trb1_ValueChanged);
            // 
            // trb2
            // 
            this.trb2.Enabled = false;
            this.trb2.Location = new System.Drawing.Point(14, 268);
            this.trb2.Maximum = 255;
            this.trb2.Name = "trb2";
            this.trb2.Size = new System.Drawing.Size(544, 45);
            this.trb2.TabIndex = 1;
            this.trb2.ValueChanged += new System.EventHandler(this.trb2_ValueChanged);
            // 
            // trb3
            // 
            this.trb3.Enabled = false;
            this.trb3.Location = new System.Drawing.Point(14, 327);
            this.trb3.Maximum = 255;
            this.trb3.Name = "trb3";
            this.trb3.Size = new System.Drawing.Size(544, 45);
            this.trb3.TabIndex = 2;
            this.trb3.ValueChanged += new System.EventHandler(this.trb3_ValueChanged);
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(-1, 404);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(688, 27);
            this.progressBar.TabIndex = 3;
            // 
            // picSystem
            // 
            this.picSystem.BackColor = System.Drawing.Color.White;
            this.picSystem.Location = new System.Drawing.Point(24, 69);
            this.picSystem.Name = "picSystem";
            this.picSystem.Size = new System.Drawing.Size(125, 113);
            this.picSystem.TabIndex = 4;
            this.picSystem.TabStop = false;
            // 
            // picUser
            // 
            this.picUser.BackColor = System.Drawing.Color.White;
            this.picUser.Location = new System.Drawing.Point(156, 69);
            this.picUser.Name = "picUser";
            this.picUser.Size = new System.Drawing.Size(125, 113);
            this.picUser.TabIndex = 5;
            this.picUser.TabStop = false;
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("Comic Sans MS", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnStart.ForeColor = System.Drawing.Color.Coral;
            this.btnStart.Location = new System.Drawing.Point(24, 12);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(116, 47);
            this.btnStart.TabIndex = 6;
            this.btnStart.Text = "Пуск";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.Enabled = false;
            this.btnStop.Font = new System.Drawing.Font("Comic Sans MS", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnStop.ForeColor = System.Drawing.Color.Red;
            this.btnStop.Location = new System.Drawing.Point(156, 12);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(125, 47);
            this.btnStop.TabIndex = 7;
            this.btnStop.Text = "Стоп";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // cbTime
            // 
            this.cbTime.DropDownHeight = 150;
            this.cbTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTime.Font = new System.Drawing.Font("Comic Sans MS", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cbTime.IntegralHeight = false;
            this.cbTime.Location = new System.Drawing.Point(301, 12);
            this.cbTime.Name = "cbTime";
            this.cbTime.Size = new System.Drawing.Size(57, 46);
            this.cbTime.TabIndex = 8;
            this.cbTime.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // tbR
            // 
            this.tbR.ForeColor = System.Drawing.Color.Red;
            this.tbR.Location = new System.Drawing.Point(555, 209);
            this.tbR.Name = "tbR";
            this.tbR.ReadOnly = true;
            this.tbR.Size = new System.Drawing.Size(55, 23);
            this.tbR.TabIndex = 9;
            this.tbR.Text = "0";
            // 
            // tbFinishR
            // 
            this.tbFinishR.ForeColor = System.Drawing.Color.Red;
            this.tbFinishR.Location = new System.Drawing.Point(620, 209);
            this.tbFinishR.Name = "tbFinishR";
            this.tbFinishR.ReadOnly = true;
            this.tbFinishR.Size = new System.Drawing.Size(55, 23);
            this.tbFinishR.TabIndex = 10;
            this.tbFinishR.Text = "0";
            this.tbFinishR.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // tbFinishG
            // 
            this.tbFinishG.ForeColor = System.Drawing.Color.Green;
            this.tbFinishG.Location = new System.Drawing.Point(620, 268);
            this.tbFinishG.Name = "tbFinishG";
            this.tbFinishG.ReadOnly = true;
            this.tbFinishG.Size = new System.Drawing.Size(55, 23);
            this.tbFinishG.TabIndex = 12;
            this.tbFinishG.Text = "0";
            // 
            // tbG
            // 
            this.tbG.ForeColor = System.Drawing.Color.Green;
            this.tbG.Location = new System.Drawing.Point(555, 268);
            this.tbG.Name = "tbG";
            this.tbG.ReadOnly = true;
            this.tbG.Size = new System.Drawing.Size(55, 23);
            this.tbG.TabIndex = 11;
            this.tbG.Text = "0";
            // 
            // tbFinishB
            // 
            this.tbFinishB.ForeColor = System.Drawing.Color.Blue;
            this.tbFinishB.Location = new System.Drawing.Point(620, 327);
            this.tbFinishB.Name = "tbFinishB";
            this.tbFinishB.ReadOnly = true;
            this.tbFinishB.Size = new System.Drawing.Size(55, 23);
            this.tbFinishB.TabIndex = 14;
            this.tbFinishB.Text = "0";
            // 
            // tbB
            // 
            this.tbB.ForeColor = System.Drawing.Color.Blue;
            this.tbB.Location = new System.Drawing.Point(555, 327);
            this.tbB.Name = "tbB";
            this.tbB.ReadOnly = true;
            this.tbB.Size = new System.Drawing.Size(55, 23);
            this.tbB.TabIndex = 13;
            this.tbB.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Fuchsia;
            this.label1.Location = new System.Drawing.Point(560, 189);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 15);
            this.label1.TabIndex = 15;
            this.label1.Text = "Текущ.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Fuchsia;
            this.label2.Location = new System.Drawing.Point(625, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 15);
            this.label2.TabIndex = 16;
            this.label2.Text = "Исход.";
            // 
            // GameTimer
            // 
            this.GameTimer.Tick += new System.EventHandler(this.GameTimer_Tick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbProcB);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.tbDelB);
            this.groupBox1.Controls.Add(this.tbProcG);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.tbDelG);
            this.groupBox1.Controls.Add(this.tbProcR);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tbDelR);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(355, 69);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(248, 113);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Результаты игры";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(7, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "Δ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Green;
            this.label4.Location = new System.Drawing.Point(7, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 15);
            this.label4.TabIndex = 1;
            this.label4.Text = "Δ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(7, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "Δ";
            // 
            // tbDelR
            // 
            this.tbDelR.ForeColor = System.Drawing.Color.Red;
            this.tbDelR.Location = new System.Drawing.Point(29, 20);
            this.tbDelR.Name = "tbDelR";
            this.tbDelR.ReadOnly = true;
            this.tbDelR.Size = new System.Drawing.Size(56, 23);
            this.tbDelR.TabIndex = 3;
            this.tbDelR.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(92, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 15);
            this.label6.TabIndex = 4;
            this.label6.Text = "Точность %";
            // 
            // tbProcR
            // 
            this.tbProcR.ForeColor = System.Drawing.Color.Red;
            this.tbProcR.Location = new System.Drawing.Point(166, 20);
            this.tbProcR.Name = "tbProcR";
            this.tbProcR.ReadOnly = true;
            this.tbProcR.Size = new System.Drawing.Size(56, 23);
            this.tbProcR.TabIndex = 5;
            this.tbProcR.Text = "0";
            // 
            // tbProcG
            // 
            this.tbProcG.ForeColor = System.Drawing.Color.Green;
            this.tbProcG.Location = new System.Drawing.Point(166, 47);
            this.tbProcG.Name = "tbProcG";
            this.tbProcG.ReadOnly = true;
            this.tbProcG.Size = new System.Drawing.Size(56, 23);
            this.tbProcG.TabIndex = 8;
            this.tbProcG.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Green;
            this.label7.Location = new System.Drawing.Point(92, 51);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 15);
            this.label7.TabIndex = 7;
            this.label7.Text = "Точность %";
            // 
            // tbDelG
            // 
            this.tbDelG.ForeColor = System.Drawing.Color.Green;
            this.tbDelG.Location = new System.Drawing.Point(29, 47);
            this.tbDelG.Name = "tbDelG";
            this.tbDelG.ReadOnly = true;
            this.tbDelG.Size = new System.Drawing.Size(56, 23);
            this.tbDelG.TabIndex = 6;
            this.tbDelG.Text = "0";
            // 
            // tbProcB
            // 
            this.tbProcB.ForeColor = System.Drawing.Color.Blue;
            this.tbProcB.Location = new System.Drawing.Point(166, 73);
            this.tbProcB.Name = "tbProcB";
            this.tbProcB.ReadOnly = true;
            this.tbProcB.Size = new System.Drawing.Size(56, 23);
            this.tbProcB.TabIndex = 11;
            this.tbProcB.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(92, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 15);
            this.label8.TabIndex = 10;
            this.label8.Text = "Точность %";
            // 
            // tbDelB
            // 
            this.tbDelB.ForeColor = System.Drawing.Color.Blue;
            this.tbDelB.Location = new System.Drawing.Point(29, 73);
            this.tbDelB.Name = "tbDelB";
            this.tbDelB.ReadOnly = true;
            this.tbDelB.Size = new System.Drawing.Size(56, 23);
            this.tbDelB.TabIndex = 9;
            this.tbDelB.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 433);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbFinishB);
            this.Controls.Add(this.tbB);
            this.Controls.Add(this.tbFinishG);
            this.Controls.Add(this.tbG);
            this.Controls.Add(this.tbFinishR);
            this.Controls.Add(this.tbR);
            this.Controls.Add(this.cbTime);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.picUser);
            this.Controls.Add(this.picSystem);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.trb3);
            this.Controls.Add(this.trb2);
            this.Controls.Add(this.trb1);
            this.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.trb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSystem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picUser)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TrackBar trb1;
        private System.Windows.Forms.TrackBar trb2;
        private System.Windows.Forms.TrackBar trb3;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.PictureBox picSystem;
        private System.Windows.Forms.PictureBox picUser;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.ComboBox cbTime;
        private System.Windows.Forms.TextBox tbR;
        private System.Windows.Forms.TextBox tbFinishR;
        private System.Windows.Forms.TextBox tbFinishG;
        private System.Windows.Forms.TextBox tbG;
        private System.Windows.Forms.TextBox tbFinishB;
        private System.Windows.Forms.TextBox tbB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer GameTimer;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbProcB;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbDelB;
        private System.Windows.Forms.TextBox tbProcG;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbDelG;
        private System.Windows.Forms.TextBox tbProcR;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbDelR;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
    }
}

