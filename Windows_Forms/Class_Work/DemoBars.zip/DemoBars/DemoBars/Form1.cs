﻿using DemoBars.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoBars
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {

            picSystem.BackColor = Color.FromArgb(Randomer.GetRGB(), Randomer.GetRGB(), Randomer.GetRGB());
            btnStart.Enabled = false;
            btnStop.Enabled = true;
            cbTime.Enabled = false;
            trb1.Enabled = true;
            trb2.Enabled = true;
            trb3.Enabled = true;
            progressBar.Value = 0;
            progressBar.Maximum = Convert.ToInt32(cbTime.Text) * 10;
            GameTimer.Start();
            trb1.Value = 0;
            trb2.Value = 0;
            trb3.Value = 0;

        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            GameTimer.Stop();
            btnStart.Enabled = true;
            btnStop.Enabled = false;
            cbTime.Enabled = true;
            trb1.Enabled = false;
            trb2.Enabled = false;
            trb3.Enabled = false;

            tbDelR.Text = Math.Abs(picSystem.BackColor.R - picUser.BackColor.R).ToString();
            tbDelG.Text = Math.Abs(picSystem.BackColor.G - picUser.BackColor.G).ToString();
            tbDelB.Text = Math.Abs(picSystem.BackColor.B - picUser.BackColor.B).ToString();

            tbFinishR.Text = picSystem.BackColor.R.ToString();
            tbFinishG.Text = picSystem.BackColor.G.ToString();
            tbFinishB.Text = picSystem.BackColor.B.ToString();

            tbProcR.Text = (100 - ((100 * (Math.Abs(picSystem.BackColor.R - picUser.BackColor.R))) / 256)).ToString();
            tbProcG.Text = (100 - ((100 * (Math.Abs(picSystem.BackColor.G - picUser.BackColor.G))) / 256)).ToString();
            tbProcB.Text = (100 - ((100 * (Math.Abs(picSystem.BackColor.B - picUser.BackColor.B))) / 256)).ToString();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbTime.DataSource = new List<int>() { 5, 10, 15, 20, 30, 45, 60 };
        }

        private void trb1_Scroll(object sender, EventArgs e)
        {

        }

        private void ChangeColor()
        {
            picUser.BackColor = Color.FromArgb(trb1.Value, trb2.Value, trb3.Value);
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            if (progressBar.Value.Equals(progressBar.Maximum))
            {
                GameTimer.Stop();
                btnStop_Click(sender, e);
            }
            else
                progressBar.Value++;
        }

        private void trb1_ValueChanged(object sender, EventArgs e)
        {
            ChangeColor();
            tbR.Text = trb1.Value.ToString();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void trb2_ValueChanged(object sender, EventArgs e)
        {
            ChangeColor();
            tbG.Text = trb2.Value.ToString();
        }

        private void trb3_ValueChanged(object sender, EventArgs e)
        {
            ChangeColor();
            tbB.Text = trb3.Value.ToString();
        }
    }
}
