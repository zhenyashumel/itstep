﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoBars.Entities
{
    public static class Randomer
    {
        private static Random rnd;

        static Randomer()
        {
            rnd = new Random();
        }

        public static int GetRGB()
        {
            return rnd.Next(256);
        }
    }
}
