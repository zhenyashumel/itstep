﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileStore.Entities
{
    public class PhoneInfo
    {
        private string model;
        private decimal price;
        private string imagePath;
        private string processor;
        private List<PhoneOptionInfo> options;
        private string os;

        public string Os
        {
            get { return os; }
            set { os = value; }
        }

        public PhoneInfo()
        {
            options = new List<PhoneOptionInfo>();

        }


        public string Processor
        {
            get { return processor; }
            set { processor = value; }
        }


        public string ImagePath
        {
            get { return imagePath; }
            set { imagePath = value; }
        }
        

     


        public decimal Price
        {
            get { return price; }
            set
            {
                if (value < 0)
                    throw new ArgumentException("price < 0");
                price = value;
            }
        }

        public string Model
        {
            get { return model; }
            set { model = value; }
        }
        public override string ToString()
        {
            return String.Format(Model);
        }
      

        public List<PhoneOptionInfo> Options
        {
            get { return options; }
        }

    }
}
