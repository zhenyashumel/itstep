﻿using MobileStore.Entities;
using MobileStore.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace MobileStore.Repository
{
    
    public static class PhoneRepository
    {
        private static BindingList<PhoneInfo> phones;
        private static List<PhoneOptionInfo> options;

        static PhoneRepository()
        {
            options = new List<PhoneOptionInfo>()
            {
                new PhoneOptionInfo(){Name = "2 Sim", Description = "1.0" },
                new PhoneOptionInfo(){Name = "Wi-fi", Description = "2.0" },
                new PhoneOptionInfo(){Name = "TV", Description = "3.0" },
                new PhoneOptionInfo(){Name = "Bluetooth", Description = "4.0" },
                new PhoneOptionInfo(){Name = "SMS/MMS", Description = "5.0" },
                new PhoneOptionInfo(){Name = "4G/LTE", Description = "6.0" },

            };
            phones = new BindingList<PhoneInfo>()
            {
                new PhoneInfo() {Model = "iPhone",Processor = "A11 Bionic", Price = 18000,Os = "IOS 11", ImagePath = @"images\Iphone.png",
                Options =
                {
                    options.Find(p=>p.Name.Equals("Wi-fi")),
                    options.Find(p=>p.Name.Equals("TV")),
                    options.Find(p=>p.Name.Equals("Bluetooth"))
                } },
                new PhoneInfo() {Model = "Samsung",Os = "Android 7.1.1",Processor = "Exynos 8895", Price = 15000,ImagePath = @"images\Samsung.png",
                Options =
                {
                    options.Find(p=>p.Name.Equals("4G/LTE")),
                    options.Find(p=>p.Name.Equals("2 Sim")),
                    options.Find(p=>p.Name.Equals("SMS/MMS"))
                }},
            };


        }
        public static IReadOnlyList<PhoneInfo> GetPhones()
        {
            return phones;
        }

        public static void AddOption(PhoneOptionInfo option)
        {
            if (option == null)
                throw new ArgumentException("option is null");
            options.Add(option);
        }

        public static void DeleteOption(PhoneOptionInfo option)
        {
            if (option == null)
                throw new ArgumentException("option is null");
            foreach (var el in phones)
            {
                foreach (var op in el.Options)
                {
                    if (op.Equals(option))
                    {
                        el.Options.Remove(option);
                        break;
                    }
                }
            }
            options.Remove(option);
        }
        public static IReadOnlyList<PhoneOptionInfo> GetOptions()
        {
            return options;
        }

        public static void AddPhone(PhoneInfo phone)
        {
            if (phone == null)
                throw new ArgumentException("phone is null");
            phones.Add(phone);
        }

        public static void ClearList()
        {
            phones.Clear();
        }
        public static void DeletePhone(PhoneInfo phone)
        {
            if (phone == null)
                throw new ArgumentException("phone is null");
            phones.Remove(phone);
        }
        public static void Save()
        {

            SerializerHelper.Serialize<PhoneInfo>("data.xml", phones);

        }
        public static void Load()
        {
            phones = SerializerHelper.Deserialize<PhoneInfo>("data.xml") as BindingList<PhoneInfo>;
        }



    }
}
