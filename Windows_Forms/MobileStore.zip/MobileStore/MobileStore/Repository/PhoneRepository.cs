﻿using MobileStore.Entities;
using MobileStore.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace MobileStore.Repository
{
    public static class PhoneRepository
    {
        private static BindingList<PhoneInfo> phones;

        static PhoneRepository()
        {
            phones = new BindingList<PhoneInfo>()
            {
                new PhoneInfo() {Model = "IPhone", Price = 18000, ImagePath = @"images\Iphone.png"},
                new PhoneInfo() {Model = "Samsung", Price = 15000,ImagePath = @"images\Samsung.png"},
            };
        }
        public static IReadOnlyList<PhoneInfo> GetPhones()
        {
            return phones;
        }

        public static void AddPhone(PhoneInfo phone)
        {
            if (phone == null)
                throw new ArgumentException("phone is null");
            phones.Add(phone);
        }

        public static void DeletePhone(PhoneInfo phone)
        {
            if (phone == null)
                throw new ArgumentException("phone is null");
            phones.Remove(phone);
        }
        public static void Save()
        {

            SerializerHelper.Serialize<PhoneInfo>("data.xml", phones);
        }
        public static void Load()
        {
            phones = SerializerHelper.Deserialize<PhoneInfo>("data.xml") as BindingList<PhoneInfo>;
        }

    }
}
