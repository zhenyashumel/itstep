﻿using MobileStore.Entities;
using MobileStore.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MobileStore
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            lstPhone.DataSource = PhoneRepository.GetPhones();
            chlstOptions.DataSource = PhoneRepository.GetOptions();

        }

        private void lstPhone_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selPhone = lstPhone.SelectedItem as PhoneInfo;
            if (selPhone != null)
            {
                tbModel.Text = selPhone.Model;
                tbProc.Text = selPhone.Processor;
                tbImage.Text = selPhone.ImagePath;
                tbPrice.Text = selPhone.Price.ToString();
                tbModel2.Text = selPhone.Model;
                tbPrice2.Text = selPhone.Price.ToString();
                tbOS.Text = selPhone.Os.ToString();
                pictureBox1.ImageLocation = selPhone.ImagePath;
                lstOptions.DataSource = null;
                lstOptions.DataSource = selPhone.Options;

                for (int i = 0; i < PhoneRepository.GetOptions().Count; i++)
                {
                    if (selPhone.Options.Any(p => p.Name.Equals((chlstOptions.Items[i] as PhoneOptionInfo).Name)))
                        chlstOptions.SetItemChecked(i, true);
                    else
                        chlstOptions.SetItemChecked(i, false);
                }
            }
        }

        private void Clear()
        {
            tbModel.Text = "";
            tbPrice.Text = "";
            pictureBox1.ImageLocation = null;
            lstOptions.DataSource = null;
            chlstOptions.DataSource = null;
            tbModel2.Text = "";
            tbPrice2.Text = "";
            tbOS.Text = "";
            tbProc.Text = "";
            tbImage.Text = "";
        }
        private void btnDel_Click(object sender, EventArgs e)
        {
            var selPhone = lstPhone.SelectedItem as PhoneInfo;
            if (selPhone != null)
            {
                PhoneRepository.DeletePhone(selPhone);
                if (PhoneRepository.GetPhones().Count.Equals(0))
                {
                    Clear();

                }
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            PhoneInfo newPhone = new PhoneInfo()
            {
                Model = tbModel2.Text,
                Price = Decimal.Parse(tbPrice2.Text),
                Processor = tbProc.Text,
                ImagePath = tbImage.Text,
                Os = tbOS.Text,    
            };
            for (int i = 0; i < PhoneRepository.GetOptions().Count; i++)
            {
                if (chlstOptions.GetItemChecked(i))
                    newPhone.Options.Add((chlstOptions.Items[i] as PhoneOptionInfo));
               
            }
            PhoneRepository.AddPhone(newPhone);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            PhoneRepository.Save();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PhoneRepository.Load();
            lstPhone.DataSource = null;
            lstPhone.DataSource = PhoneRepository.GetPhones();
            chlstOptions.DataSource = null;
            chlstOptions.DataSource = PhoneRepository.GetOptions();

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            PhoneRepository.ClearList();
            Clear();
        }

        private void btnSaveChange_Click(object sender, EventArgs e)
        {
            var selPhone = lstPhone.SelectedItem as PhoneInfo;

            selPhone.Model = tbModel2.Text;
            selPhone.ImagePath = tbImage.Text;
            selPhone.Os = tbOS.Text;
            selPhone.Price = Convert.ToDecimal(tbPrice2.Text);
            selPhone.Processor = tbProc.Text;
            selPhone.Options.Clear();
            for (int i = 0; i < PhoneRepository.GetOptions().Count; i++)
            {
                if (chlstOptions.GetItemChecked(i))
                    selPhone.Options.Add((chlstOptions.Items[i] as PhoneOptionInfo));
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.ImageLocation = null;
            lstOptions.DataSource = null;
            for (int i = 0; i < PhoneRepository.GetOptions().Count; i++)
                chlstOptions.SetItemChecked(i, false);
            tbModel2.Text = "";
            tbPrice2.Text = "";
            tbOS.Text = "";
            tbProc.Text = "";
            tbImage.Text = "";
        }

        private void btnAddOption_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(tbOptionName.Text))
                return;

            else if (PhoneRepository.GetOptions().Any(p => p.Name == tbOptionName.Text))
                return;

            PhoneRepository.AddOption(new PhoneOptionInfo() { Name = tbOptionName.Text });
            chlstOptions.DataSource = null;
            chlstOptions.DataSource = PhoneRepository.GetOptions();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            PhoneRepository.DeleteOption(chlstOptions.SelectedItem as PhoneOptionInfo);
            chlstOptions.DataSource = null;
            chlstOptions.DataSource = PhoneRepository.GetOptions();
          
        }

        private void chlstOptions_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
