﻿using MobileStore.Entities;
using MobileStore.Repository;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MobileStore
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            lstPhone.DataSource = PhoneRepository.GetPhones();
        }

        private void lstPhone_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selPhone = lstPhone.SelectedItem as PhoneInfo;
            if (selPhone != null)
            {
                tbModel.Text = selPhone.Model;
                tbPrice.Text = selPhone.Price.ToString();
                pictureBox1.ImageLocation = selPhone.ImagePath;
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            var selPhone = lstPhone.SelectedItem as PhoneInfo;
            if (selPhone != null)
            {
                PhoneRepository.DeletePhone(selPhone);
                if(PhoneRepository.GetPhones().Count.Equals(0))
                {
                    tbModel.Text = "";
                    tbPrice.Text = "";
                    pictureBox1.ImageLocation = null;
                }
            }
           
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            PhoneInfo newPhone = new PhoneInfo()
            {
                Model = tbModel.Text,
                Price = Decimal.Parse(tbPrice.Text)
            };
            PhoneRepository.AddPhone(newPhone);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            PhoneRepository.Save();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PhoneRepository.Load();
            lstPhone.DataSource = null;
            lstPhone.DataSource = PhoneRepository.GetPhones();

        }
    }
}
