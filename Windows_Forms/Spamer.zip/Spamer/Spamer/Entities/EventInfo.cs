﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spamer.Entities
{
    [Serializable]
    public class EventInfo
    {
        #region fields
        private List<string> addresses;
        private DateTime date;
        private int hours;
        private int minutes;
        private string message;
        private string cause;
        private string comment;
        #endregion

        public EventInfo(List<string> Addresses, DateTime Date, int Hours, int Minutes, string Message, string Cause, string Comment)
        {
            if (Addresses == null || Addresses.Count == 0)
                throw new ArgumentException("Addresses is null or empty!!!");
            if (Date == null)
                throw new ArgumentException("Date is null!!!");
            if (Hours < 0 && Hours > 24)
                throw new ArgumentException("Invalid Hours!!!");
            if (Minutes < 0 && Minutes > 24)
                throw new ArgumentException("Invalid Minutes!!!");
            if (String.IsNullOrWhiteSpace(Message))
                throw new ArgumentException("Message is empty!!!");
            if (String.IsNullOrWhiteSpace(Cause))
                throw new ArgumentException("Cause is empty!!!");
            //комментарий заполнять необязательно

            addresses = Addresses;
            date = Date;
            hours = Hours;
            minutes = Minutes;
            message = Message;
            cause = Cause;
            comment = Comment;
        }
        #region Properties
        [DisplayName("Дата")]
        public DateTime Date { get { return date; } }

        
        public IReadOnlyList<string> Addresses()
        {
            return addresses;
        }

        [DisplayName("Часы")]
        public int Hours { get { return hours; } }

        [DisplayName("Минуты")]
        public int Minutes { get { return minutes; } }
        [DisplayName("Сообщение")]
        public string Message { get { return message; } }
        [DisplayName("Тема")]
        public string Cause { get { return cause; } }
        [DisplayName("Комментарий")]
        public string Comment { get { return comment; } }
        #endregion
    }
}
