﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spamer.Entities
{
    [Serializable]
    public class ResultInfo
    {
        private DateTime date;
        private int hours;
        private int minutes;
        private string address;
        private string sender;
        private string theme;       

        public ResultInfo(DateTime Date, int Hours, int Minutes, string Address, string Sender, string Theme)
        {
            if (Date == null)
                throw new ArgumentException("Date is null");

            if (Hours < 0 && Hours > 24)
                throw new ArgumentException("Invalid Hours!!!");
            if (Minutes < 0 && Minutes > 24)
                throw new ArgumentException("Invalid Minutes!!!");
            if (String.IsNullOrWhiteSpace(Address))
                throw new ArgumentException("Address is empty!!!");
            if (String.IsNullOrWhiteSpace(Theme))
                throw new ArgumentException("Theme is empty!!!");

            date = Date;
            hours = Hours;
            minutes = Minutes;
            address = Address;
            sender = Sender;
            theme = Theme;
           
        }

        #region properties
        [DisplayName("Дата")]
        public string Date
        {
            get
            {
                return String.Format(date.ToString("dd.mm.yyyy") + " " + hours + ":" + minutes);
            }

        }
        [DisplayName("Кому")]
        public string Address { get { return address; } }
        [DisplayName("От кого")]
        public string Sender { get { return sender; } }
        [DisplayName("Тема")]
        public string Theme { get { return theme; } }
        #endregion
    }
}
