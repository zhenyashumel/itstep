﻿using Spamer.Entities;
using Spamer.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spamer
{
    public static class ResultRepository
    {
        private static BindingList<ResultInfo> results;

        static ResultRepository()
        {
            results = new BindingList<ResultInfo>();
            if (File.Exists("results.txt"))
            {
                LoadResults();
            }
        }

        public static BindingList<ResultInfo> Results { get { return results; } }

        public static void AddResult(ResultInfo Result)
        {
            if (Result == null)
                throw new ArgumentException("Result is null");
            results.Add(Result);
            SaveResults();

        }
        public static void LoadResults()
        {
            results = (BindingList<ResultInfo>)SerializerHelper.Deserialize<ResultInfo>("results.txt");
        }

        public static void SaveResults()
        {
            SerializerHelper.Serialize<ResultInfo>("results.txt", results);
        }
        public static void DeleteResults()
        {
            results.Clear();
            SaveResults();
        }
    }
}
