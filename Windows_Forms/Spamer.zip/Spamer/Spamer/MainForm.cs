﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spamer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }



        private void AddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddUserForm form = new AddUserForm();
            if (form.ShowDialog() == DialogResult.OK)
            {
                TreeNode newNode = new TreeNode()
                {
                    Text = form.UserName,
                    ToolTipText = form.UserEmail
                };

                treeView1.SelectedNode.Nodes.Add(newNode);
            }
        }

        private void treeView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                treeView1.SelectedNode = treeView1.GetNodeAt(e.X, e.Y);
            }
        }

        private void miSave_Click(object sender, EventArgs e)
        {
            BinaryFormatter formater = new BinaryFormatter();
            using (FileStream file = new FileStream("data.dat", FileMode.OpenOrCreate))
            {
                List<TreeNode> nodes = new List<TreeNode>();
                foreach (TreeNode item in treeView1.Nodes)
                {
                    nodes.Add(item);
                }
                formater.Serialize(file, nodes);
            }

        }

        private void miLoad_Click(object sender, EventArgs e)
        {
            BinaryFormatter formater = new BinaryFormatter();
            using (FileStream file = new FileStream("data.dat", FileMode.Open))
            {
                var nodes = (List<TreeNode>)formater.Deserialize(file);
                treeView1.Nodes.Clear();
                foreach (var item in nodes)
                {
                    treeView1.Nodes.Add(item);
                }
            }
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbEvents.DataSource = new List<string>()
            {
                "День Рождения",
                "Новый Год",
                "Свадьба",
                "Закончил 'Шаг'",
                "Другое"
            };
        }

        private void GetAllNames(TreeNode selTN)
        {
            for (int i = 0; i < selTN.Nodes.Count; i++)
            {
                GetAllNames(selTN.Nodes[i]);
                if (selTN.Nodes[i].Level >= 3)
                {
                    tbNames.Text += selTN.Nodes[i].Text + ";";
                    tbAddress.Text += selTN.Nodes[i].ToolTipText + ";";
                }
            }

        }

        private void treeView1_AfterSelect_1(object sender, TreeViewEventArgs e)
        {
            tbNames.Text = String.Empty;
            tbAddress.Text = String.Empty;
            if (treeView1.SelectedNode.Level == 3)
            {
                tbNames.Text = treeView1.SelectedNode.Text;
                tbAddress.Text = treeView1.SelectedNode.ToolTipText;
            }
            else
                GetAllNames(treeView1.SelectedNode);
        }
    }
}
