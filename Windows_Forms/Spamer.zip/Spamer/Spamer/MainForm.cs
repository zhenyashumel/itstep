﻿using Spamer.Entities;
using Spamer.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spamer
{
    public partial class Form1 : Form
    {
        private List<string> selectedAddresses;

        public Form1()
        {
            selectedAddresses = new List<string>();
            InitializeComponent();
            backgroundWorker1.WorkerReportsProgress = true;
            backgroundWorker1.WorkerSupportsCancellation = true;
            backgroundWorker1.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorker1_RunWorkerCompleted);
            notifyIcon1.Visible = false;


        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }


        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            tslbInfo.Text = "Готово";
            tsStatusBar.Visible = false;
        }
        private void AddToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddUserForm form = new AddUserForm();
            if (form.ShowDialog() == DialogResult.OK)
            {
                TreeNode newNode = new TreeNode()
                {
                    Text = form.UserName,
                    ToolTipText = form.UserEmail,
                    ContextMenuStrip = cmiUserNode
                };

                treeView1.SelectedNode.Nodes.Add(newNode);
            }
        }

        private void treeView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                treeView1.SelectedNode = treeView1.GetNodeAt(e.X, e.Y);
            }
        }

        private void miSave_Click(object sender, EventArgs e)
        {
            BinaryFormatter formater = new BinaryFormatter();
            using (FileStream file = new FileStream("data.dat", FileMode.OpenOrCreate))
            {
                List<TreeNode> nodes = new List<TreeNode>();
                foreach (TreeNode item in treeView1.Nodes)
                {
                    nodes.Add(item);
                }
                formater.Serialize(file, nodes);
            }

        }

        private void miLoad_Click(object sender, EventArgs e)
        {
            BinaryFormatter formater = new BinaryFormatter();
            using (FileStream file = new FileStream("data.dat", FileMode.Open))
            {
                var nodes = (List<TreeNode>)formater.Deserialize(file);
                treeView1.Nodes.Clear();
                foreach (var item in nodes)
                {
                    treeView1.Nodes.Add(item);
                }
            }
            LoadContextMenuStrip(treeView1.Nodes[0]);


        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            monthCalendar1.SelectionStart = DateTime.Now;
            dataGridView1.DataSource = ResultRepository.Results;
            cbEvents.DataSource = new List<string>()
            {
                "День Рождения",
                "Новый Год",
                "Свадьба",
                "Закончил 'Шаг'",
                "Другое"
            };

            CheckTimer.Start();
        }

        private void GetAllNames(TreeNode selTN)
        {
            for (int i = 0; i < selTN.Nodes.Count; i++)
            {
                GetAllNames(selTN.Nodes[i]);
                if (selTN.Nodes[i].Level >= 3)
                {
                    tbNames.Text += selTN.Nodes[i].Text + "; ";
                    tbAddress.Text += selTN.Nodes[i].ToolTipText + "; ";
                    selectedAddresses.Add(selTN.Nodes[i].ToolTipText);
                }
            }

        }

        private void LoadContextMenuStrip(TreeNode selTN)
        {
            for (int i = 0; i < selTN.Nodes.Count; i++)
            {
                LoadContextMenuStrip(selTN.Nodes[i]);
                if (selTN.Nodes[i].Level >= 3)
                {
                    selTN.Nodes[i].ContextMenuStrip = cmiUserNode;
                }

                if (selTN.Nodes[i].Level == 2)
                    selTN.Nodes[i].ContextMenuStrip = cmiNode;

            }

        }


        private void treeView1_AfterSelect_1(object sender, TreeViewEventArgs e)
        {
            tbNames.Text = String.Empty;
            tbAddress.Text = String.Empty;
            selectedAddresses.Clear();
            if (treeView1.SelectedNode.Level == 3)
            {
                tbNames.Text = treeView1.SelectedNode.Text;
                tbAddress.Text = treeView1.SelectedNode.ToolTipText;
                selectedAddresses.Add(treeView1.SelectedNode.ToolTipText);
            }
            else
                GetAllNames(treeView1.SelectedNode);
        }

        private void RemoveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            treeView1.SelectedNode.Remove();
        }

        private bool Check()
        {

            tslbInfo.Text = "Готово";
            tslbInfo.ForeColor = Color.Empty;
            if (selectedAddresses.Count == 0)
            {
                tslbInfo.ForeColor = Color.Red;
                tslbInfo.Text = "Выберете получателей";
                return false;
            }


            if (monthCalendar1.SelectionStart.Date < DateTime.Now.Date)
            {
                tslbInfo.ForeColor = Color.Red;
                tslbInfo.Text = "Введена некорректная дата";
                return false;
            }

            if (monthCalendar1.SelectionStart.Date == DateTime.Now.Date)
            {
                if (DateTime.Now.Hour > numHours.Value ||
                    (DateTime.Now.Hour == numHours.Value && DateTime.Now.Minute > nuMinutes.Value))
                {
                    tslbInfo.ForeColor = Color.Red;
                    tslbInfo.Text = "Введено некорректное время";
                    return false;

                }
            }

            if (tbMessage.Text.Equals(String.Empty))
            {
                tslbInfo.ForeColor = Color.Red;
                tslbInfo.Text = "Введите сообщение";
                return false;
            }

            return true;

        }
        private void miAddEvent_Click(object sender, EventArgs e)
        {
            if (Check())
            {
                EventInfo newEvent = new EventInfo(this.selectedAddresses, monthCalendar1.SelectionStart.Date,
                   (int)numHours.Value, (int)nuMinutes.Value, tbMessage.Text, cbEvents.SelectedItem.ToString(), tbComment.Text);

                EventsRepository.AddEvent(newEvent);

            }
        }

        private void SendMessage(EventInfo Event)
        {


        }

        private void CheckTimer_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < EventsRepository.Events.Count; i++)
            {
                if (EventsRepository.Events[i].Date == DateTime.Now.Date)
                {
                    if (DateTime.Now.Hour >= EventsRepository.Events[i].Hours &&
                        DateTime.Now.Minute >= EventsRepository.Events[i].Minutes)
                    {
                        if (!backgroundWorker1.IsBusy)
                        {
                            backgroundWorker1.RunWorkerAsync(EventsRepository.Events[i]);
                            tsStatusBar.Visible = true;
                            tslbInfo.Text = "Отправка";
                        }
                    }

                }
            }
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            var Event = e.Argument as EventInfo;
            if (Event == null)
                throw new ArgumentException("Event is null");


            SmtpClient Smtp = new SmtpClient("smtp.mail.ru", 25)
            {
                Credentials = new NetworkCredential("ivanitstep@mail.ru", "ivan123456789"),
                EnableSsl = true
            };


            MailMessage message = new MailMessage
            {
                From = new MailAddress("ivanitstep@mail.ru")
            };

            for (int i = 0; i < Event.Addresses().Count; i++)
            {
                message.To.Add(new MailAddress(Event.Addresses()[i]));
            }

            message.Subject = Event.Cause;
            message.Body = Event.Message;
            Smtp.Send(message);
            EventsRepository.Events.Remove(Event);

            for (int i = 0; i < Event.Addresses().Count; i++)
            {
                ResultInfo result = new ResultInfo(DateTime.Now.Date, Event.Hours, Event.Minutes, Event.Addresses()[i], "ivanitstep@mail.ru", Event.Cause);
                ResultRepository.AddResult(result);
            }
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        private void Form1_Deactivate(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.ShowInTaskbar = false;
                notifyIcon1.Visible = true;
               
            }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
           
            notifyIcon1.Visible = false;           
            this.ShowInTaskbar = true;            
            WindowState = FormWindowState.Normal;
        }

        private void miDeleteEvents_Click(object sender, EventArgs e)
        {
            EventsRepository.DeleteEvents();
        }

        private void miDeleteResult_Click(object sender, EventArgs e)
        {
            ResultRepository.DeleteResults();
        }

        private void miShowEvents_Click(object sender, EventArgs e)
        {
            EventsForm eventsForm = new EventsForm();
            eventsForm.Show();
        }

        private void miAbout_Click(object sender, EventArgs e)
        {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        }

        private void miExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
