﻿using Spamer.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Spamer.Helpers;
namespace Spamer
{
    public static class EventsRepository
    {
        private static List<EventInfo> events;

        static EventsRepository()
        {
            events = new List<EventInfo>();
            if (File.Exists("events.txt"))
            {
                LoadEvents();
            }
        }

        public static List<EventInfo> Events { get { return events; }  }

        public static void AddEvent(EventInfo Event)
        {
            if (Event == null)
                throw new ArgumentException("Event is null");
            events.Add(Event);
            SaveEvents();

        }
        public static void LoadEvents()
        {
            events = (List<EventInfo>)SerializerHelper.Deserialize<EventInfo>("events.txt");
            foreach(var item in events)
            {
                if(item.Date < DateTime.Now.Date)
                {
                    events.Remove(item);
                }
                if(item.Date == DateTime.Now.Date && item.Hours < DateTime.Now.Hour)
                {
                    events.Remove(item);
                }
                
            }
        }

        public static void SaveEvents()
        {
            SerializerHelper.Serialize<EventInfo>("events.txt", events);
        }

        public static void DeleteEvents()
        {
            events.Clear();
            SaveEvents();
        }
    }
}

