﻿using System;

namespace _02.Command.Implementation
{
    class Reciever
    {
        public void Action()
        {
            Console.WriteLine(nameof(Reciever));
        }
    }
}
