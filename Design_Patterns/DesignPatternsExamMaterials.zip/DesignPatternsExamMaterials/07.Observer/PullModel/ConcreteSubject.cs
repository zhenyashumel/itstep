﻿namespace _07.Observer.PullModel
{
    class ConcreteSubject : Subject
    {
        public string State { get; set; }
    }
}