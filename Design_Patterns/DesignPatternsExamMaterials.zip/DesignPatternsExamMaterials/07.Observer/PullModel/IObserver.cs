﻿namespace _07.Observer.PullModel
{
    interface IObserver
    {
        void Update();
    }
}
