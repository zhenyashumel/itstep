﻿namespace _07.Observer.PushModel
{
    interface IObserver
    {
        void Update(string state);
    }
}
