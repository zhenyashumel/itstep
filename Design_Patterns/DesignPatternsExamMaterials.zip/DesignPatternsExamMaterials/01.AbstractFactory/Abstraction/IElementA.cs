﻿namespace _01.AbstractFactory.Abstraction
{
    internal interface IElementA
    {
        void InteractWith(IElementB elementB);
    }
}