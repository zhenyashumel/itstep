namespace _01.AbstractFactory.Abstraction
{
    internal interface IElementB
    {
    }
}