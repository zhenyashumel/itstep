using _01.AbstractFactory.Abstraction;

namespace _01.AbstractFactory.Implementation
{
    internal class ElementB : IElementB
    {
    }
}