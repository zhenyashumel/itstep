﻿namespace _03.FactoryMethod.Abstraction
{
    public abstract class AbstractProduct
    {
        public abstract string Description { get; }
    }
}