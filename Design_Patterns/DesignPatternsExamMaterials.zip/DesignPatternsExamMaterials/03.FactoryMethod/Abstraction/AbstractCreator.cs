﻿namespace _03.FactoryMethod.Abstraction
{
    public abstract class AbstractCreator
    {
        public abstract AbstractProduct Create();
    }
}