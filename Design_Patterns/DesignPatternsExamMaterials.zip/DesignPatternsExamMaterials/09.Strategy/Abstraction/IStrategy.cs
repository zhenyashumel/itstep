﻿namespace _09.Strategy.Abstraction
{
    public interface IStrategy
    {
        void UseAlgorithm();
    }
}