﻿namespace _02.Proxy
{
    interface ISubject
    {
        void Request();
    }
}
