﻿namespace _06.MementoSample
{
    /// <summary>
    /// Посыльный
    /// </summary>
    internal class Caretaker
    {
        public Memento Memento { get; set; }
    }
}