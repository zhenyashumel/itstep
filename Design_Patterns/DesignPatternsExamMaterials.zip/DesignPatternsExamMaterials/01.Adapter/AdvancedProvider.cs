﻿using System;

namespace _01.Adapter
{
    class AdvancedProvider
    {
        public void Make()
        {
            Console.WriteLine("Making some advanced work!");
        }
    }
}
