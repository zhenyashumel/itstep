﻿namespace _01.Adapter
{
    abstract class Provider
    {
        public abstract void Do();
    }
}