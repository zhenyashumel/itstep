﻿using System;

namespace _04.Facade
{
    internal class SubsystemB 
    {
        public void DoSomeWork()
        {
            Console.WriteLine("aking complex work in subsystem B");
        }
    }
}