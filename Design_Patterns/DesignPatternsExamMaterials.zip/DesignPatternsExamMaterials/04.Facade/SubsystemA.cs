﻿using System;

namespace _04.Facade
{
    internal class SubsystemA 
    {
        public void DoWork()
        {
            Console.WriteLine("aking complex work in subsystem A");
        }
    }
}
