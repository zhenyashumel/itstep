﻿namespace _03.Interpreter
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
