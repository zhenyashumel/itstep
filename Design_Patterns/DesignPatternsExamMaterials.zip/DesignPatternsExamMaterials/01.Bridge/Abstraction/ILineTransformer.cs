﻿namespace _01.Bridge.Abstraction
{
    interface ILineTransformer
    {
        DataItem Transform(string line);
    }
}