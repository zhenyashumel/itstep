﻿namespace _01.Bridge
{
    class DataItem
    {
        public string Name { get; set; }

        public string Organisation { get; set; }
    }
}
