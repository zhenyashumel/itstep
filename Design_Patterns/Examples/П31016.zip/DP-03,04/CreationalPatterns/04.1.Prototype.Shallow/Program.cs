﻿using System;

namespace _04._1.Prototype.Shallow
{
    internal class Program
    {
        private static void Main()
        {
            var user = new User
            {
                FirstName = "John",
                LastName = "Doe",
                Credentials = new Credentials
                {
                    Login = "johnnydoe",
                    Password = "qwerty"
                }
            };

            var clonedUser = user.Clone();

            user.FirstName = "Mark";
            user.Credentials.Login = "markdoe";

            Console.WriteLine(user);
            Console.WriteLine(clonedUser);

            Console.ReadKey();
        }
    }

    class User : ICloneable
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public Credentials Credentials { get; set; }

        public object Clone()
        {
            User newUser = (User)MemberwiseClone();
            newUser.Credentials = (Credentials)newUser.Credentials.Clone();
            return newUser;
        }

        public override string ToString()
        {
            // return $"{FirstName} {LastName}";
            return $"{FirstName} {LastName} [{Credentials.Login}%{Credentials.Password}]";
        }
    }

    class Credentials : ICloneable
    {
        public string Login { get; set; }

        public string Password { get; set; }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
