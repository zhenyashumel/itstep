﻿using _03.FactoryMethod.Abstraction;

namespace _03.FactoryMethod
{
    internal class ConcreteProduct : AbstractProduct
    {
        public override string Description => "Some Concrete Product";
    }
}
