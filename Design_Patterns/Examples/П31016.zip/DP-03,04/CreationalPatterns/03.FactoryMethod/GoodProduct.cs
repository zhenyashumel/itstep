﻿using _03.FactoryMethod.Abstraction;

namespace _03.FactoryMethod
{
    internal class GoodProduct : AbstractProduct
    {
        public override string Description => "Good product";
    }
}
