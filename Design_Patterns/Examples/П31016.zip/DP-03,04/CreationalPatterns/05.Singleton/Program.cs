﻿using System;

namespace _05.Singleton
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var link1 = Singleton.Instance;

            var link2 = Singleton.Instance;

            Console.WriteLine(link1.GetHashCode());
            Console.WriteLine(link2.GetHashCode());

            Console.ReadKey();
        }
    }
}
