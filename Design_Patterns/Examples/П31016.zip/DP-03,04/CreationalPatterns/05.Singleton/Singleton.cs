﻿namespace _05.Singleton
{
    internal class Singleton
    {
        private static Singleton _instance;
        
        private Singleton() { }

        // Lazy loading
        public static Singleton Instance
        {
            get
            {
                if(_instance == null)
                {
                    _instance = new Singleton();
                }

                return _instance;
            }
        }
    }
}
