﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Database
{
    public class Database
    {
        private readonly IList<string> _models = new List<string>
        {
            "BMW",
            "Lada",
            "Mercedes-Benz",
            "Opel",
            "Peugeot",
            "Renault",
            "Honda",
            "Skoda",
            "Audi",
            "Lifan",
            "Mitsubishi"
        }; 

        private readonly Random _random = new Random((int)DateTime.Now.Ticks);

        public string GetCarModel(string identifier)
        {
            Thread.Sleep(3000);
            return _models[_random.Next(0, _models.Count - 1)];
        }
    }
}
