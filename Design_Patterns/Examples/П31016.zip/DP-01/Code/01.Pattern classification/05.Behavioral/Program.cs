﻿using System;

namespace _05.Behavioral
{
    class Class1
    {
        public void Do()
        {
            Console.WriteLine("Class1.Do()");
        }
    }

    class Class2
    {
        public void Do()
        {
            var item1 = new Class1();
            item1.Do();
            Console.WriteLine("Class2.Do()");
        }
    }

    class Chain
    {
        public void Start()
        {
            var item2 = new Class2();
            item2.Do();
            Console.WriteLine("Chain.Start()");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var chain = new Chain();            
            chain.Start();

            Console.ReadKey();
        }
    }
}
