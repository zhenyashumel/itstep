﻿using System;

namespace _02.Creational.Why
{
    class ImportantDocumentFactory
    {
        public ComplexDocument CreateImportantDocument()
        {
            return new ComplexDocument
            {
                Extension = "rtf",
                Owner = "Director",
                StoreTerm = 365,
                Tag = ConsoleColor.DarkRed
            };
        }

        public ComplexDocument CreateRegularDocument()
        {
            return new ComplexDocument
            {
                Extension = "txt",
                Owner = "Worker",
                StoreTerm = 900,
                Tag = ConsoleColor.Green
            };
        }
    }

    class ComplexDocument
    {
        public string Extension { get; set; }

        public string Owner { get; set; }

        public int StoreTerm { get; set; }

        public ConsoleColor Tag { get; set; }

        public void Load()
        {
            Console.ForegroundColor = Tag;
            Console.WriteLine($"Document with extension {Extension}, owned by {Owner} has been successfully loaded!");
            Console.ForegroundColor = ConsoleColor.White;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {            
            var factory = new ImportantDocumentFactory();

            var importantDocument1 = factory.CreateImportantDocument();
            importantDocument1.Load();
            var importantDocument2 = factory.CreateImportantDocument();
            importantDocument2.Load();
            var importantDocument3 = factory.CreateImportantDocument();
            importantDocument3.Load();

            var importantDocument4 = new ComplexDocument
            {
                Extension = "docx",
                Owner = "",
                StoreTerm = 1,
                Tag = ConsoleColor.Black
            };


            var regularDocument1 = factory.CreateRegularDocument();
            regularDocument1.Load();
            var regularDocument2 = factory.CreateRegularDocument();
            regularDocument2.Load();
            var regularDocument3 = factory.CreateRegularDocument();
            regularDocument3.Load();

            // delay
            Console.ReadKey();
        }
    }
}
