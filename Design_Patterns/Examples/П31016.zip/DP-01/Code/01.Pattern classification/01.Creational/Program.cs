﻿using System;

namespace _01.Creational
{
    // Фабрика документов
    class DocumentFactory
    {
        // Создаёт новый документ (фабричный метод)
        public Document Create()
        {
            return new Document();
        }
    }

    // Класс, описывающий документ
    class Document
    {
        public Document()
        {
            Console.WriteLine("Hello, I am a new document!");
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            // создаём экземпляр фабрики
            var factory = new DocumentFactory();

            // вызываем метод, создающий новый документ
            Document document = factory.Create();
            
            // delay
            Console.ReadKey();
        }
    }
}
