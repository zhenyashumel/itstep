﻿using System;

namespace _04.Structural.Why
{
    class ConnectionOpener
    {
        public void OpenConnection(string url) { Console.WriteLine($"Connection opened to \"{url}\""); }
    }

    class ReportCreator
    {
        public void CreateReport() { Console.WriteLine("Report created"); }
    }

    class ResultPrinter
    {
        public void PrintResult() { Console.WriteLine("Result printed"); }
    }

    class ReportFacade
    {
        private ConnectionOpener _connectionOpener = new ConnectionOpener();
        private ReportCreator _reportCreator = new ReportCreator();
        private ResultPrinter _resultPrinter = new ResultPrinter();
        
        public void GetReport()
        {
            _connectionOpener.OpenConnection("myorg.com");
            _reportCreator.CreateReport();
            _resultPrinter.PrintResult();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var reportFacade = new ReportFacade();
            reportFacade.GetReport();

            Console.ReadKey();
        }
    }

    //class FraudRecordsSeeker
    //{
    //    public void FindFraudRecords() { Console.WriteLine("All fraud records have been found"); }
    //}
}
