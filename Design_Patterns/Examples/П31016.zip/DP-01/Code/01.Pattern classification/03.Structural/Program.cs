﻿using System;

namespace _03.Structural
{
    class HelloSayer
    {
        public void Hello()  { Console.Write("Hello,"); }
    }

    class WorldSayer
    {
        public void World() { Console.WriteLine(" world!"); }
    }

    class Facade
    {
        private readonly HelloSayer _helloSayer = new HelloSayer();
        private readonly WorldSayer _worldSayer = new WorldSayer();

        public void HelloWorld()
        {
            _helloSayer.Hello();
            _worldSayer.World();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //var facade = new Facade();
            //facade.HelloWorld();

            var helloSayer = new HelloSayer();
            

            var worldSayer = new WorldSayer();
            worldSayer.World();
            helloSayer.Hello();

            Console.ReadKey();
        }
    }
}
