﻿namespace ConsoleApp1.Abstraction
{
    abstract class Case
    {
        public abstract void PutLaptop(Laptop laptop);

        public abstract void GetLaptop(Laptop laptop);
    }
}