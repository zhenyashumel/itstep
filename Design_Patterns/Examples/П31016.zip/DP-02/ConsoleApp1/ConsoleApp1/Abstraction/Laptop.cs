﻿namespace ConsoleApp1.Abstraction
{
    abstract class Laptop
    {
        public abstract void TurnOn();
    }
}