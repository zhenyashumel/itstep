﻿namespace ConsoleApp1.Abstraction
{
    abstract class LaptopFactory
    {
        public abstract Laptop CreateLaptop();
        public abstract Case CreateCase();
    }
}
