﻿using ConsoleApp1.Abstraction;

namespace ConsoleApp1.Asus
{
    class AsusFactory : LaptopFactory
    {
        public override Laptop CreateLaptop()
        {
            return new ZenBook();
        }

        public override Case CreateCase()
        {
            return new AsusCase();
        }
    }
}
