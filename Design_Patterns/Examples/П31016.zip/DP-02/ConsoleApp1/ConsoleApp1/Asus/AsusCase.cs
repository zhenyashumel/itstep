﻿using System;
using ConsoleApp1.Abstraction;

namespace ConsoleApp1.Asus
{
    internal class AsusCase : Case
    {
        public override void PutLaptop(Laptop laptop)
        {
            Console.WriteLine("Putting laptop into asus corporate case.");
        }

        public override void GetLaptop(Laptop laptop)
        {
            Console.WriteLine("Getting laptop from asus case.");
        }
    }
}