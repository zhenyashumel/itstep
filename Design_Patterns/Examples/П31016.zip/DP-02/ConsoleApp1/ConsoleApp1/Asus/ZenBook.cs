﻿using System;
using ConsoleApp1.Abstraction;

namespace ConsoleApp1.Asus
{
    internal class ZenBook : Laptop
    {
        public override void TurnOn()
        {
            Console.WriteLine("Hello I'm your ZenBook, and i'm loading Windows 10 for you...");
        }
    }
}