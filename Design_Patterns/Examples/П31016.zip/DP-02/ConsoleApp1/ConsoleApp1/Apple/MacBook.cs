﻿using System;
using ConsoleApp1.Abstraction;

namespace ConsoleApp1.Apple
{
    class MacBook : Laptop
    {
        public override void TurnOn()
        {
            Console.WriteLine("Hello I'm a MacBook, and I'm working for you!");
        }
    }
}
