﻿using ConsoleApp1.Abstraction;

namespace ConsoleApp1.Apple
{
    class MacBookFactory : LaptopFactory
    {
        public override Laptop CreateLaptop()
        {
            return new MacBook();
        }

        public override Case CreateCase()
        {
            return new MacBookCase();
        }
    }
}
