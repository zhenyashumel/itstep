﻿using System;
using ConsoleApp1.Abstraction;

namespace ConsoleApp1.Apple
{
    class MacBookCase : Case
    {
        public override void PutLaptop(Laptop laptop)
        {
            Console.WriteLine("Putting laptop into beautiful and useful MacBook case.");
        }

        public override void GetLaptop(Laptop laptop)
        {
            Console.WriteLine("Getting laptop from MacBook case.");
        }
    }
}
