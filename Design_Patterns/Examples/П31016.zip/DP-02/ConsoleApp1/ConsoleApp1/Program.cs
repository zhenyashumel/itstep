﻿using System;
using ConsoleApp1.Abstraction;
using ConsoleApp1.Apple;
using ConsoleApp1.Asus;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            LaptopFactory factory = new MacBookFactory();

            Laptop myLaptop = factory.CreateLaptop();
            Case myCase = factory.CreateCase();

            myCase.PutLaptop(myLaptop);
            myCase.GetLaptop(myLaptop);
            myLaptop.TurnOn();
            myCase.PutLaptop(myLaptop);

            // Delay
            Console.ReadKey();
        }
    }
}
