﻿namespace ConsoleApp2.Abstraction
{
    interface IDiploma
    {
        string RegNumber { get; }
    }
}
