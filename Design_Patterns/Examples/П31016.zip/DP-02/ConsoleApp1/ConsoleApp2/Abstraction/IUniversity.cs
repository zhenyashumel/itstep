﻿namespace ConsoleApp2.Abstraction
{
    interface IUniversity
    {
        ISpecilast Graduate();

        IDiploma GetDiploma();
    }
}
