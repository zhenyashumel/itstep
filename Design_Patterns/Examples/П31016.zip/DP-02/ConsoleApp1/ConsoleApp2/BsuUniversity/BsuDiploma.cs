﻿using ConsoleApp2.Abstraction;

namespace ConsoleApp2.BsuUniversity
{
    class BsuDiploma : IDiploma
    {
        public string RegNumber => "BSU-100501";
    }
}
