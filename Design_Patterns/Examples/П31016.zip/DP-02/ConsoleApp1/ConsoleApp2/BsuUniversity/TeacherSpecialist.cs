﻿using ConsoleApp2.Abstraction;
using System;

namespace ConsoleApp2.BsuUniversity
{
    class TeacherSpecialist : ISpecilast
    {
        public void FindWork(IDiploma diploma)
        {
            Console.WriteLine($"Teacher from BSU found work with diploma {diploma.RegNumber}");
        }
    }
}
