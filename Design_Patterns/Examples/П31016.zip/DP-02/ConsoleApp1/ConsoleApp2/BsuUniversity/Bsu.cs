﻿using ConsoleApp2.Abstraction;

namespace ConsoleApp2.BsuUniversity
{
    class Bsu : IUniversity
    {
        public IDiploma GetDiploma() => new BsuDiploma();

        public ISpecilast Graduate() => new TeacherSpecialist();
    }
}
