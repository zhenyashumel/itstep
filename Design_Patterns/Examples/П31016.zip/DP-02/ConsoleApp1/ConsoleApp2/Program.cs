﻿using ConsoleApp2.Abstraction;
using ConsoleApp2.BsuirUniversity;
using ConsoleApp2.BsuUniversity;
using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            IUniversity university = new Bsu();

            var specialist = university.Graduate();
            var diploma = university.GetDiploma();

            specialist.FindWork(diploma);

            Console.ReadKey();
        }
    }
}
