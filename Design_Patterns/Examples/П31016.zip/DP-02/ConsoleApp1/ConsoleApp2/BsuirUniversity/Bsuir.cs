﻿using ConsoleApp2.Abstraction;

namespace ConsoleApp2.BsuirUniversity
{
    class Bsuir : IUniversity
    {
        public IDiploma GetDiploma()
        {
            return new BsuirDiploma();
        }

        public ISpecilast Graduate()
        {
            return new TelecommunicationSpecialist();
        }
    }
}
