﻿using ConsoleApp2.Abstraction;

namespace ConsoleApp2.BsuirUniversity
{
    class BsuirDiploma : IDiploma
    {
        public string RegNumber => "BSUIR-10500";
    }
}
