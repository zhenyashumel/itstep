﻿using ConsoleApp2.Abstraction;
using System;

namespace ConsoleApp2.BsuirUniversity
{
    class TelecommunicationSpecialist : ISpecilast
    {
        public void FindWork(IDiploma diploma)
        {
            Console.WriteLine($@"Telecommunacation specialist 
                from bsuir sucessfully found new work 
                with his diploma with number {diploma.RegNumber}!");
        }
    }
}
