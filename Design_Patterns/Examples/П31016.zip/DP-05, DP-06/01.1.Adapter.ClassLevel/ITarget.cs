﻿namespace _01._1.Adapter.ClassLevel
{
    interface ITarget
    {
        void Insert();
    }
}
