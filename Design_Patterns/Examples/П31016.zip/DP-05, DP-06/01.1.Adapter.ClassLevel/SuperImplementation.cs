﻿using System;

namespace _01._1.Adapter.ClassLevel
{
    class  SuperImplementation
    {
        public void SuperInsert()
        {
            Console.WriteLine("SuperInsert method invoked perfectly!");
        }
    }
}
