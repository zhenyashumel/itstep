﻿namespace _01._1.Adapter.ClassLevel
{
    class NewTargetImplementation : SuperImplementation, ITarget
    {
        public void Insert()
        {
            SuperInsert();
        }
    }
}
