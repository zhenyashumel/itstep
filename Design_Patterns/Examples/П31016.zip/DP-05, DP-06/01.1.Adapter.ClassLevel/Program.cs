﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01._1.Adapter.ClassLevel
{
    class Program
    {
        static void Main(string[] args)
        {            
            ITarget targetInstance = new NewTargetImplementation();

            Consumer.Use(targetInstance);

            Console.ReadKey();
        }
    }
}
