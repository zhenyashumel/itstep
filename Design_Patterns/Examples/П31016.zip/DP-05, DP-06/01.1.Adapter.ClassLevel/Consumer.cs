﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01._1.Adapter.ClassLevel
{
    class Consumer
    {
        public static void Use(ITarget target)
        {
            target.Insert();
        }  
    }
}
