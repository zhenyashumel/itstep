﻿using System;

namespace _01._1.Adapter.ClassLevel
{
    class TargetImplementation : ITarget
    {
        public void Insert()
        {
            Console.WriteLine("Insert method invoked correctly!");
        }
    }
}
