﻿using System;

namespace _02.Proxy
{
    class Proxy : ISubject
    {
        private Subject _subject = new Subject();

        public void Request()
        {
            _subject.Request();

            Console.WriteLine("Send additional report");
        }
    }
}
