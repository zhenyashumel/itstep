﻿using System;

namespace Parser
{
    internal class Program
    {
        private static void Main(string[] args)
        {            
        }
    }
}
