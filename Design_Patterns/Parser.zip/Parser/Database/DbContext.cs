﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Database
{
    public class DbContext
    {
        private readonly IList<string> _models = new List<string>
        {
            "BMW|M5|2000",
            "BMW|M5|2001",
            "BMW|X3|2012",
            "BMW|X3|2017",
            "Lada|Xray|2018",
            "Lada|Xray|2017",
            "Mercedes-Benz|C-Classe|1998",
            "Mercedes-Benz|C-Classe|1983",
            "Mercedes-Benz|A-Classe|2007",
            "Mercedes-Benz|A-Classe|2017",
            "Mercedes-Benz|B-Classe|2017",
            "Mercedes-Benz|B-Classe|2018",
            "Opel|Corsa|1997",
            "Opel|Ascona|1983",
            "Opel|Ascona|1984",
            "Opel|Astra|1996",
            "Opel|Signum|2007",
            "Peugeot|406|2003",
            "Peugeot|408|2014",
            "Peugeot|405|2004",
            "Peugeot|3008|2017",
            "Renault|Laguna|2005",
            "Renault|Laguna|2006",
            "Renault|Laguna|2007",
            "Renault|Laguna|2004",
            "Renault|Logan|2014",
            "Renault|Logan|2015",
            "Renault|Megane|2016",
            "Renault|Duster|*AD",
            "Renaadsdas",
            "Honda|Accord|2009",
            "Honda|Civic|2005",
            "Skoda|Rapid|2014",
            "Skoda|Octavia|2017",
            "Audi|A4|2009",
            "Audi|A6|2009",
            "Audi|A8|2014",
            "Audi|A8L|1900",
            "Audi|Q3|2017",
            "Audi|Q5|2018",
            "Audi|Q7|2018"
        }; 

        private readonly Random _random = new Random((int)DateTime.Now.Ticks);

        public string GetCarInfo(string identifier)
        {
            Thread.Sleep(3000);
            return _models[_random.Next(0, _models.Count - 1)];
        }
    }
}
